﻿<?php
/*

* @Developed by Dominator!?
*/
$usrv = mysql_query("SELECT * FROM `users` WHERE `user_id` = '".$_SESSION['user_id']."'");
$usrv_r = mysql_fetch_array($usrv);
class resultController extends Controller {
	public function index() {
		$this->load->model('users');
		$this->load->model('invoices');
		
		if($this->request->server['REQUEST_METHOD'] == 'POST') {
			$errorPOST = $this->validatePOST();
			if(!$errorPOST) {
				$ammount = $this->request->post['OutSum'];
				$invid = $this->request->post['InvId'];
				$signature = $this->request->post['SignatureValue'];
				
				$invoice = $this->invoicesModel->getInvoiceById($invid);
				$userid = $invoice['user_id'];
				
				$this->usersModel->upUserBalance($userid, $ammount);
				$this->invoicesModel->updateInvoice($invid, array('invoice_status' => 1));
				
				if($usrv_r['user_refid'] > 0 && $ammount >= 20){
				$procent = (($ammount*10)/100);
				$this->usersModel->upUserBalance($usrv_r['user_refid'], $procent);
				mysql_query("UPDATE `users` SET `user_refmoney`=`user_refmoney`+'".$procent."' WHERE `user_id`='".$usrv_r['user_refid']."'");
				}
				return "OK$invid\n";
			} else {
				return "Error: $errorPOST";
			}
		} else {
			return "Error: Invalid request!";
		}
	}
	
	private function validatePOST() {
		$result = null;
		
		$ammount = $this->request->post['OutSum'];
		$invid = $this->request->post['InvId'];
		$signature = $this->request->post['SignatureValue'];
		
		$password2 = $this->config->rk_password2;
		
		if(!$this->invoicesModel->getTotalInvoices(array('invoice_id' => (int)$invid))) {
			$result = "Invalid invoice!";
		}
		elseif(strtoupper($signature) != strtoupper(md5("$ammount:$invid:$password2"))) {
			$result = "Invalid signature!";
		}
		return $result;
	}
}
?>
