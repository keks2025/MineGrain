﻿<?php
class monitorController extends Controller {
	private $limit = 50;
	public function index($page = 1) {
		if($this->user->getAccessLevel() < 1) {
			$this->session->data['error'] = "У вас нет доступа к данному разделу!";
			$this->response->redirect($this->config->url);
		}
		
		$this->document->setActiveSection('monitor');
    $this->document->setActiveItem('index');
		$this->load->library('query');
		$this->load->library('pagination');
		$this->load->model('servers');
		$getData = array();
		
		$getOptions = array(
			'start' => ($page - 1) * $this->limit,
			'limit' => $this->limit
		);
		
		$total = $this->serversModel->getTotalServers($getData);
		$servers = $this->serversModel->getServers($getData, array('games', 'locations'), array(), $getOptions);
		$paginationLib = new paginationLibrary();
		
		$paginationLib->total = $total;
		$paginationLib->page = $page;
		$paginationLib->limit = $this->limit;
		$paginationLib->url = $this->config->url . 'main/monitor/index/{page}';
		
		$pagination = $paginationLib->render();
		$this->data['servers'] = $servers;
		$this->data['pagination'] = $pagination;
		$this->getChild(array('common/header', 'common/footer'));
		return $this->load->view('main/monitor', $this->data);
	}
}
?>
