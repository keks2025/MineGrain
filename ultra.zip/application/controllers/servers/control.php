<?php
/*
* @Слито RAG20
*/
class controlController extends Controller {
	public function index($serverid = null) {
		$this->document->setActiveSection('servers');
		$this->document->setActiveItem('index');
		
		if(!$this->user->isLogged()) {
			$this->session->data['error'] = "Вы не авторизированы!";
			$this->response->redirect($this->config->url . 'account/login');
		}
		if($this->user->getAccessLevel() < 0) {
			$this->session->data['error'] = "У вас нет доступа к данному разделу!";
			$this->response->redirect($this->config->url);
		}
		
		$this->load->library('query');
		$this->load->model('servers');
		$this->load->model('serversStats');
		$this->load->model('users');
		
		$this->data['user_balance'] = $this->user->getBalance();
		
		$error = $this->validate($serverid);
		if($error) {
			$this->session->data['error'] = $error;
			$this->response->redirect($this->config->url . 'servers/index');
		}
		
		$userid = $this->user->getId();
		
		$server = $this->serversModel->getServerById($serverid, array('games', 'locations'));
		$this->data['server'] = $server;
		
		if($server['server_status'] == 2) {
			$queryLib = new queryLibrary($server['game_query']);
			$queryLib->connect($server['location_ip'], $server['server_port']);
			$query = $queryLib->getInfo();
			$queryLib->disconnect();
			
			$this->data['query'] = $query;
		}
		
		$stats = $this->serversStatsModel->getServerStats($serverid, "NOW() - INTERVAL 1 DAY", "NOW()");
		$this->data['stats'] = $stats;
		
		$this->getChild(array('common/header', 'common/footer'));
		return $this->load->view('servers/control', $this->data);
	}
	
	public function action($serverid = null, $action = null) {
		if(!$this->user->isLogged()) {
			$this->data['status'] = "error";
			$this->data['error'] = "Вы не авторизированы!";
			return json_encode($this->data);
		}
		if($this->user->getAccessLevel() < 0) {
	  		$this->data['status'] = "error";
			$this->data['error'] = "У вас нет доступа к данному разделу!";
			return json_encode($this->data);
		}
		
		$this->load->model('servers');
		$this->load->library('ssh2');
		
		$ssh2Lib = new ssh2Library();
		
		$error = $this->validate($serverid);
		if($error) {
			$this->data['status'] = "error";
			$this->data['error'] = $error;
			return json_encode($this->data);
		}
		
		$server = $this->serversModel->getServerById($serverid, array('users', 'locations', 'games'));
        $link = $ssh2Lib->connect($server['location_ip'], $server['location_user'], $server['location_password']);
		
		switch($action) {
			case 'start': {
				if($server['server_status'] == 1) {
					$result = $this->serversModel->execServerAction($serverid, 'start');
					if($result['status'] == "OK") {
						$this->serversModel->updateServer($serverid, array('server_status' => 2));
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно запустили сервер!";
					} else {
						$this->data['status'] = "error";
						$this->data['error'] = $result['description'];
					}
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = "Сервер должен быть выключен!";
				}
				break;
			}
			case 'reinstall': {
				if($server['server_status'] == 1) {
					$result = $this->serversModel->execServerAction($serverid, 'reinstall');
					if($result['status'] == "OK") {
						$this->serversModel->updateServer($serverid, array('server_status' => 1));
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно переустановили сервер!";
					} else {
						$this->data['status'] = "error";
						$this->data['error'] = $result['description'];
					}
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = "Сервер должен быть выключен!";
				}
				break;
			}
			case 'restart': {
				if($server['server_status'] == 2) {
					$result = $this->serversModel->execServerAction($serverid, 'restart');
					if($result['status'] == "OK") {
						$this->serversModel->updateServer($serverid, array('server_status' => 2));
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно перезапустили сервер!";
					} else {
						$this->data['status'] = "error";
						$this->data['error'] = $result['description'];
					}
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = "Сервер должен быть включен!";
				}
				break;
			}
			case 'stop': {
				if($server['server_status'] == 2) {
					$result = $this->serversModel->execServerAction($serverid, 'stop');
					if($result['status'] == "OK") {
						$this->serversModel->updateServer($serverid, array('server_status' => 1));
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно выключили сервер!";
					} else {
						$this->data['status'] = "error";
						$this->data['error'] = $result['description'];
					}
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = "Сервер должен быть включен!";
				}
				break;
			}
			case 'backup': {
				if($server['server_status'] == 1) {
				$output = $ssh2Lib->execute($link, "cd /home/gs$serverid && tar -cvf backup.tar *");
				$ssh2Lib->disconnect($link);
				$this->data['status'] = "success";
				$this->data['success'] = "Вы успешно сделали бэкап сервера!";
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = "Сервер должен быть выключен!";
				}
				break;
			}
			case 'unbackup': {
				if($server['server_status'] == 1) {
				if (file_exists('ftp://gs'.$server['server_id'].':'.$server['server_password'].'@'.$server['location_ip'].':21/backup.tar')) {
				$output = $ssh2Lib->execute($link, "cd /home/gs$serverid && tar -xvf backup.tar");
				$ssh2Lib->disconnect($link);
				$this->data['status'] = "success";
				$this->data['success'] = "Вы успешно восстановили бэкап сервера!";
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = "У вас нет бэкапа сервера!";
				}
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = "Сервер должен быть выключен!";
				}
				break;
			}
			case 'quota50': {
			$output = $ssh2Lib->execute($link, "sudo edquota -p quotaconf gs$serverid");
			$ssh2Lib->disconnect($link);
						mysql_query("UPDATE `servers` SET `server_quota`='50' WHERE `server_id`='$server[server_id]'");
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно установили дисковой лимит 50 МБ!";
				break;
			}
			case 'quota150': {
			if($this->user->getBalance() >= 7.50) {
			$output = $ssh2Lib->execute($link, "sudo edquota -p quotaconf150 gs$serverid");
			$ssh2Lib->disconnect($link);
						mysql_query("UPDATE `servers` SET `server_quota`='150' WHERE `server_id`='$server[server_id]'");
						mysql_query("UPDATE `users` SET `user_balance`=`user_balance` - 7.50 WHERE `user_id`='$_SESSION[user_id]'");
						mysql_query("INSERT INTO `waste` 
				    (`waste_id`, `user_id`, `waste_ammount`, `waste_status`, `waste_usluga`, `waste_date_add`) 
				    VALUES 
				   (NULL, '{$_SESSION['user_id']}', '7.50', 1, 'Изменение квоты до 150 МБ для сервера gs$serverid', NOW())");
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно установили дисковой лимит 150 МБ!";
			 } else {
					$this->data['status'] = "error";
					$this->data['error'] = "На вашем балансе недостаточно средств!";
				}
				break;
			}
			case 'quota300': {
			if($this->user->getBalance() >= 15) {
			  $output = $ssh2Lib->execute($link, "sudo edquota -p quotaconf300 gs$serverid");
				$ssh2Lib->disconnect($link);
						mysql_query("UPDATE `servers` SET `server_quota`='300' WHERE `server_id`='$server[server_id]'");
						mysql_query("UPDATE `users` SET `user_balance`=`user_balance` - 15 WHERE `user_id`='$_SESSION[user_id]'");
						mysql_query("INSERT INTO `waste` 
				   (`waste_id`, `user_id`, `waste_ammount`, `waste_status`, `waste_usluga`, `waste_date_add`) 
				   VALUES 
				   (NULL, '{$_SESSION['user_id']}', '15', 1, 'Изменение квоты до 300 МБ для сервера gs$serverid', NOW())");
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно установили дисковой лимит 300 МБ!";
			 } else {
					$this->data['status'] = "error";
					$this->data['error'] = "На вашем балансе недостаточно средств!";
				}
				break;
			}
			case 'createdb': {
			if($server['database'] == 0) {
			      mysql_query("create database gs".$server['server_id']);
		        mysql_query("grant usage on *.* to gs".$server['server_id']."@'%' identified by '".$server['server_password']."'");
		        mysql_query("grant all privileges on gs".$server['server_id'].".* to gs".$server['server_id']."@'%'");
						mysql_query("UPDATE `servers` SET `database`='1' WHERE `server_id`='$server[server_id]'");
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно активировали базу данных!";
			 } else {
					$this->data['status'] = "error";
					$this->data['error'] = "База данных уже активирована!";
				}
				break;
			}
			case 'delldb': {
			if($server['database'] == 1) {
			      mysql_query("DROP DATABASE gs".$server['server_id']);
						mysql_query("UPDATE `servers` SET `database`='0' WHERE `server_id`='$server[server_id]'");
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно отключили базу данных!";
			 } else {
					$this->data['status'] = "error";
					$this->data['error'] = "База данных уже отключена.";
				}
				break;
			}
			case 'svz': {
				if($server['server_status'] == 1) {
				if($server['game_id'] == 8) {
				$this->data['status'] = "error";
				$this->data['error'] = "Версия вашего сервера и так SA:MP 0.3z!";
				}else{
						$this->serversModel->updateServer($serverid, array('server_status' => 1));
						$this->serversModel->updateServer($serverid, array('game_id' => 8));
						$this->serversModel->execServerAction($serverid, 'reinstall');
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно установили версию SA:MP 0.3z!";
				}
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = "Сервер должен быть выключен!";
				}
				break;
			}
			case 'svx': {
				if($server['server_status'] == 1) {
				if($server['game_id'] == 11) {
				$this->data['status'] = "error";
				$this->data['error'] = "Версия вашего сервера и так SA:MP 0.3x!";
				}else{
						$this->serversModel->updateServer($serverid, array('server_status' => 1));
						$this->serversModel->updateServer($serverid, array('game_id' => 11));
						$this->serversModel->execServerAction($serverid, 'reinstall');
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно установили версию SA:MP 0.3x!";
				}
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = "Сервер должен быть выключен!";
				}
				break;
			}
			case 'sve': {
				if($server['server_status'] == 1) {
				if($server['game_id'] == 10) {
				$this->data['status'] = "error";
				$this->data['error'] = "Версия вашего сервера и так SA:MP 0.3e!";
				}else{
						$this->serversModel->updateServer($serverid, array('server_status' => 1));
						$this->serversModel->updateServer($serverid, array('game_id' => 10));
						$this->serversModel->execServerAction($serverid, 'reinstall');
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно установили версию SA:MP 0.3e!";
				}
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = "Сервер должен быть выключен!";
				}
				break;
			}
			case 'sv037': {
				if($server['server_status'] == 1) {
				if($server['game_id'] == 12) {
				$this->data['status'] = "error";
				$this->data['error'] = "Версия вашего сервера и так SA:MP 0.3.7!";
				}else{
						$this->serversModel->updateServer($serverid, array('server_status' => 1));
						$this->serversModel->updateServer($serverid, array('game_id' => 12));
						$this->serversModel->execServerAction($serverid, 'reinstall');
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно установили версию SA:MP 0.3.7!";
				}
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = "Сервер должен быть выключен!";
				}
				break;
			}
			case 'cve': {
				if($server['server_status'] == 1) {
				if($server['game_id'] == 9) {
				$this->data['status'] = "error";
				$this->data['error'] = "Версия вашего сервера и так CR:MP 0.3e!";
				}else{
						$this->serversModel->updateServer($serverid, array('server_status' => 1));
						$this->serversModel->updateServer($serverid, array('game_id' => 9));
						$this->serversModel->execServerAction($serverid, 'reinstall');
						$this->data['status'] = "success";
						$this->data['success'] = "Вы успешно установили версию CR:MP 0.3e!";
				}
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = "Сервер должен быть выключен!";
				}
				break;
			}
			default: {
				$this->data['status'] = "error";
				$this->data['error'] = "Вы выбрали несуществующее действие!";
				break;
			}
		}
		
		return json_encode($this->data);
	}
	
	public function ajax($serverid = null) {
		if(!$this->user->isLogged()) {  
	  		$this->data['status'] = "error";
			$this->data['error'] = "Вы не авторизированы!";
			return json_encode($this->data);
		}
		if($this->user->getAccessLevel() < 1) {
	  		$this->data['status'] = "error";
			$this->data['error'] = "У вас нет доступа к данному разделу!";
			return json_encode($this->data);
		}
		
		$this->load->model('servers');
		
		$error = $this->validate($serverid);
		if($error) {
			$this->data['status'] = "error";
			$this->data['error'] = $error;
			return json_encode($this->data);
		}
		
		if($this->request->server['REQUEST_METHOD'] == 'POST') {
			$errorPOST = $this->validatePOST();
			if(!$errorPOST) {
				$editpassword = @$this->request->post['editpassword'];
				$password = @$this->request->post['password'];
				
				if($editpassword) {
					$serverData['server_password'] = $password;
				}
				
				$result = $this->serversModel->execServerAction($serverid, 'updatepassword');
				if($result['status'] == "OK") {
					$this->serversModel->updateServer($serverid, $serverData);
					$this->data['status'] = "success";
					$this->data['success'] = "Вы успешно отредактировали сервер!";
				} else {
					$this->data['status'] = "error";
					$this->data['error'] = $result['description'];
				}
			} else {
				$this->data['status'] = "error";
				$this->data['error'] = $errorPOST;
			}
		}

		return json_encode($this->data);
	}
	
	private function validate($serverid) {
		$result = null;
		
		$userid = $this->user->getId();
		
		if(!$this->serversModel->getTotalServers(array('server_id' => (int)$serverid, 'user_id' => (int)$userid))) {
			$result = "Запрашиваемый сервер не существует!";
		}
		return $result;
	}
	
	private function validatePOST() {
		$this->load->library('validate');
		
		$validateLib = new validateLibrary();
		
		$result = null;
		
		$editpassword = @$this->request->post['editpassword'];
		$password = @$this->request->post['password'];
		$password2 = @$this->request->post['password2'];
		
		if($editpassword) {
			if(!$validateLib->password($password)) {
				$result = "Пароль должен содержать от 6 до 32 латинских букв, цифр и знаков <i>,.!?_-</i>!";
			}
			elseif($password != $password2) {
				$result = "Введенные вами пароли не совпадают!";
			}
		}
		return $result;
	}
}
?>