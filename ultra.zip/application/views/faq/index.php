﻿<?php echo $header ?>
<h3 class="box-title">FAQ</h3><br>
<div class="panel-group" id="collapse-group">
 <div class="panel panel-default">
 <div class="panel-heading">
 <h4 class="panel-title">
 <a data-toggle="collapse" data-parent="#collapse-group" href="#el1">Ошибка FilesError</a>
 </h4>
 </div>
 <div id="el1" class="panel-collapse collapse">
 <div class="panel-body">Данная ошибка говорит о том что Вы затронули заменили или удалили бинарные файлы сервера, решается переустановкой сервера.<br>
						Названия бинарных файлов. <br>
						SAMP: samp03svr, samp-npc, announce. <br>
						CRMP: samp03svr-cr, samp-npc, announcr. <br>
						МТА SA: mta-server. <br>
						CS 1.6: hlds_amd, hlds_i486, hlds_i686, hlds_run.<br /></div>
 </div>
 </div>
 <div class="panel panel-default">
 <div class="panel-heading">
 <h4 class="panel-title">
 <a data-toggle="collapse" data-parent="#collapse-group" href="#el2">Ошибка ConfigError</a>
 </h4>
 </div>
 <div id="el2" class="panel-collapse collapse">
 <div class="panel-body">Данная ошибка говорит о том что не правильно настроен конфиг (server.cfg).<br>
						В конфиге должна быть строка bind (ip как в панели).<br>
						Должны быть указаны параметры только те что в панели. <br>
						maxplayers (кол-во слотов как в панели). <br>
						port (порт как в панели).<br>
						bind (ip как в панели).<br /></div>
 </div>
 </div>
 <div class="panel panel-default">
 <div class="panel-heading">
 <h4 class="panel-title">
 <a data-toggle="collapse" data-parent="#collapse-group" href="#el3">Ошибка UnknownResponse</a>
 </h4>
 </div>
 <div id="el3" class="panel-collapse collapse">
 <div class="panel-body">Данная ошибка решается переименовыванием сервера английскими буквами. <br /></div>
 </div>
 </div>
 <div class="panel panel-default">
 <div class="panel-heading">
 <h4 class="panel-title">
 <a data-toggle="collapse" data-parent="#collapse-group" href="#el4">Информация перед установкой плагинов</a>
 </h4>
 </div>
 <div id="el4" class="panel-collapse collapse">
 <div class="panel-body">1. Устанавливайте только нужные Вам плагины.<br> 2. Слишком большое количество плагинов может вызвать увеличение пинга и лаги.<br> 3. Некоторые сочетания плагинов могут вызвать нестабильную работу сервера.<br /></div>
 </div>
 </div>
 <div class="panel panel-default">
 <div class="panel-heading">
 <h4 class="panel-title">
 <a data-toggle="collapse" data-parent="#collapse-group" href="#el5">Почему сервер Unknown</a>
 </h4>
 </div>
 <div id="el5" class="panel-collapse collapse">
 <div class="panel-body">Проверьте наличие плагинов .so для вашего сервера в папке plugins, а также прописаны ли они в настройках сервера.<br /></div>
 </div>
 </div>
 <div class="panel panel-default">
 <div class="panel-heading">
 <h4 class="panel-title">
 <a data-toggle="collapse" data-parent="#collapse-group" href="#el6">Не запускается сервер SAMP,CRMP</a>
 </h4>
 </div>
 <div id="el6" class="panel-collapse collapse">
 <div class="panel-body">Прежде чем искать решение проблемы и писать нам в тех.поддержку в первую очередь необходимо выяснить, что за ошибка вам попалась.
Для этого вам необходимо посмотреть логи сервера и логи запуска сервера.
Это файлы server_log.txt и screenlog. Посмотреть вы их можете через ФТП, например.
В эти файлы записываются всё, что сервер отдает в командную строку.</div>
 </div>
 </div>
 <div class="panel panel-default">
 <div class="panel-heading">
 <h4 class="panel-title">
 <a data-toggle="collapse" data-parent="#collapse-group" href="#el7">Ручное добавление bind в файл конфигурации</a>
 </h4>
 </div>
 <div id="el7" class="panel-collapse collapse">
 <div class="panel-body">Если получилось так, что вам как-то удалось заменить наш стандартный файл конфигурации на свой, где нет строки bind, или просто удалить эту строку из нашего, то для нормальной работы сервера (да и вообще для любой) стоит эту строку вернуть назад. Ваши действия:
Скачать на компьютер файл конфигурации server.cfg
Открыть файл в любом текстовом редакторе и добавить в самый конец такую строку:<br>
bind<br>
Сохранить файл<br>
Закачать файл назад по фтп с заменой старого<br /></div>
 </div>
 </div>
 <div class="panel panel-default">
 <div class="panel-heading">
 <h4 class="panel-title">
 <a data-toggle="collapse" data-parent="#collapse-group" href="#el8">server.cfg (SAMP,CRMP)</a>
 </h4>
 </div>
 <div id="el8" class="panel-collapse collapse">
 <div class="panel-body">echo - Все, что стоит после этого параметра - будет выводится в консоль сервера при запуске. Стандартно установлено Executing Server Config...<br>
lanmode - Указывает где работает сервер, в интернете или в локальной сети, 0 для интернета. Стандартно значение установлено на 0<br>
maxplayers.<br>
announce - Включает/выключает отображение сервера в Интернете.<br>
port - Порт сервера.<br>
hostname - Название вашего сервера.<br>
gamemode(n) (N) (t) - Игровой мод<br>
weburl - Адрес вашего сайта.<br>
rcon_password - RCON пароль сервера.<br>
filterscripts (N) - Скрипты<br>
plugins (N) - Плагины<br>
password (p) - Пароль сервера<br>
mapname (m) - Название карты<br>
bind - Указывает, на каком IP адресе работает сервер. Запрещено изменять на нашем хостинге.<br>
rcon 0/1 - Включает/выключает возможность использования RCON-консоли.<br>
maxnpc - Кол-во ботов, которые могут быть использоваться на сервере.<br>
onfoot_rate - Технический параметр.<br>
incar_rate - Технический параметр.<br>
weapon_rate - Технический параметр.<br>
stream_distance - Технический параметр.<br>
stream_rate - Технический параметр.<br>
Какой будет пинг?<br>
Проверить пинг и общее качество игрового сервера вы можете на тестовых демо серверах.</div>
 </div>
 </div>
 <div class="panel panel-default">
 <div class="panel-heading">
 <h4 class="panel-title">
 <a data-toggle="collapse" data-parent="#collapse-group" href="#el9">Как подключиться к серверу через ftp?</a>
 </h4>
 </div>
 <div id="el9" class="panel-collapse collapse">
 <div class="panel-body">1. Скачать ftp-клиент, например: FileZilla<br>
2. После запуска программы необходимо указать данные от ftp-сервера, их вы получите в управлении вашего игрового сервера, в разделе "FTP Доступ".<br>
- в поле хост, введите ip-адрес сервера, с портам (21);<br>
- в поле имя пользователя, введите ваш логин от ftp;<br>
- в поле пароль, введите ваш пароль от ftp;<br>
- поле порт указать "21";<br>
3. После ввода данных, нажмите "Быстрое соединение"<br>
В правом нижнем углу загрузится структура вашего игрового сервера. Здесь вы можете устанавливать любые плагины и выполнять любые настройки своего игрового сервера.<br /></div>
 </div>
 </div>
<div class="panel panel-default">
 <div class="panel-heading">
 <h4 class="panel-title">
 <a data-toggle="collapse" data-parent="#collapse-group" href="#el10">Что такое купон?</a>
 </h4>
 </div>
 <div id="el10" class="panel-collapse collapse">
 <div class="panel-body">Купон - это код,который вы вводите при заказе сервера,для получения скидки. (Вводить не обязательно).<br/>Следить за новыми купонами вы можете в разделе "<a href="/promo">Купон</a>".</div>
 </div>
 </div>
</div>
<?php echo $footer ?>