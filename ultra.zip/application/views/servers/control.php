<?php
/*
* @Слито RAG20
*/
require_once('./engine/libs/ssh2.php');
$ssh2Lib = new ssh2Library();
$link = $ssh2Lib->connect($server['location_ip'], $server['location_user'], $server['location_password']);

$gamePrice = $server['game_price'];
if($_POST['buy_slots']){
	if($_POST['slots'] >= '10' && $_POST['slots'] <= '1000' && $_POST['slots'] != $server['server_slots']){
		$sslots = $server['server_slots'];
		$slots = $_POST['slots'];
		if($sslots == $slots){
			$price = '0';
		} else {
			if($slots-$sslots <= 0) {
				$price = '0';
			} else {
				$price = $gamePrice * ($slots-$sslots);
			}
		}
		if($price){
			if($user_balance-$price >= '0'){
				$newbalance = $user_balance-$price;
				$minus = $slots-$sslots;
				mysql_query("UPDATE  `servers` SET `server_slots` =  '".$_POST['slots']."' WHERE  `server_id` = '{$server['server_id']}'");
				mysql_query("UPDATE  `users` SET `user_balance` =  '{$newbalance}' WHERE  `user_id` = '{$_SESSION['user_id']}'");
				mysql_query("INSERT INTO `waste` 
				(`waste_id`, `user_id`, `waste_ammount`, `waste_status`, `waste_usluga`, `waste_date_add`) 
				VALUES 
				(NULL, '{$_SESSION['user_id']}', '{$price}', 1, 'Увеличение слотов (+{$minus}) для сервера gs{$server['server_id']}', NOW())");
				$msg = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">×</a><b>Выполнено!</b> Вы приобрели '. $minus .' слотов для сервера.</div>';
			} else {
				$msg = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">×</a><b>Ошибка!</b> На вашем балансе недостаточно средств.</div>';
			}
		 } else {
		   $minus = $slots-$sslots;
		   mysql_query("UPDATE  `servers` SET `server_slots` =  '".$_POST['slots']."' WHERE  `server_id` = '{$server['server_id']}'");
			 $msg = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">×</a><b>Выполнено!</b> Вы уменьшили '. $minus .' слотов для сервера.</div>';
	   }
	}
}
if($_POST['buy_port']){
if($_POST['port'] >= '1111' && $_POST['port'] <= '60000' && $_POST['port'] != $server['server_port']){
if (mysql_num_rows(mysql_query("SELECT 1 FROM `servers` WHERE  `server_port` = '".$_POST['port']."' AND `location_id` = '".$server['location_id']."'")) == 0) {
if($user_balance >= '100'){
mysql_query("UPDATE  `servers` SET `server_port` =  '".$_POST['port']."' WHERE  `server_id` = '{$server['server_id']}'");
mysql_query("UPDATE  `users` SET `user_balance` =  `user_balance` - 100 WHERE  `user_id` = '{$_SESSION['user_id']}'");
mysql_query("INSERT INTO `waste` 
(`waste_id`, `user_id`, `waste_ammount`, `waste_status`, `waste_usluga`, `waste_date_add`) 
VALUES 
(NULL, '{$_SESSION['user_id']}', '100', 1, 'Установка порта ".$_POST['port']." для сервера gs{$server['server_id']}', NOW())");
$msg = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">×</a><b>Выполнено!</b> Вы приобрели порт '.$_POST['port'].' для сервера.</div>';
} else {
$msg = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">×</a><b>Ошибка!</b> На вашем балансе недостаточно средств.</div>';
}
} else {
$msg = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">×</a><b>Ошибка!</b> Данный порт уже занят.</div>';
}
}
}
?>
<?php echo $header ?>
<?if(!empty($msg)):?><?=$msg?><?endif;?>
				<div class="page-header">
					<h1>Управление сервером</h1>
				</div>
				<?php if ($server['server_status'] > 0){ ?>
				<ul class="nav nav-tabs">
  <li class="active"><a data-toggle="tab" href="#server"><span class="glyphicon glyphicon-hdd"></span> Сервер</a></li>
  <li><a data-toggle="tab" href="#ver"><span class="glyphicon glyphicon-refresh"></span> Версия</a></li>
  <li><a data-toggle="tab" href="#stat"><span class="glyphicon glyphicon-globe"></span> Статистика</a></li>
  <li><a data-toggle="tab" href="#cmd"><span class="glyphicon glyphicon-barcode"></span> Консоль</a></li>
  <li><a data-toggle="tab" href="#config"><span class="glyphicon glyphicon-file"></span> Редактор</a></li>
</ul><br/>
<?php } ?>
<div class="tab-content">
  <div id="server" class="tab-pane fade in active">
				<div class="panel panel-success">
					<div class="panel-heading">Информация о сервере</div>
					<table class="table table-bordered">
					<th width="200px" rowspan="20">
								<div align="Center"><img src="<?php echo $server['image_url']?>" style="width:160px; margin-bottom:5px;"></div>
								<?php if($server['server_status'] == 1): ?> 
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-success" onClick="sendAction(<?php echo $server['server_id'] ?>,'start')"><span class="glyphicon glyphicon-off"></span> Включить</button>
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-warning" onClick="sendAction(<?php echo $server['server_id'] ?>,'reinstall')"><span class="glyphicon glyphicon-refresh"></span> Переустановить</button>
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-warning" onClick="sendAction(<?php echo $server['server_id'] ?>,'backup')"><span class="glyphicon glyphicon-save"></span> Бэкап</button>
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-warning" onClick="sendAction(<?php echo $server['server_id'] ?>,'unbackup')"><span class="glyphicon glyphicon-open"></span> Развернуть бэкап</button>
								<?php elseif($server['server_status'] == 2): ?> 
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-danger" onClick="sendAction(<?php echo $server['server_id'] ?>,'stop')"><span class="glyphicon glyphicon-off"></span> Выключить</button>
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-info" onClick="sendAction(<?php echo $server['server_id'] ?>,'restart')"><span class="glyphicon glyphicon-refresh"></span> Перезапустить</button>
								<?php endif; ?>
							</th>
						<tr>
							<th>Игра:</th>
							<td><?php echo $server['game_name'] ?></td>
						</tr>
						<tr>
							<th>Локация:</th>
							<td><?php echo $server['location_name'] ?></td>
						</tr>
						<tr>
							<th>Адрес:</th>
							<td><?php echo $server['location_ip'] ?>:<?php echo $server['server_port'] ?></td>
						  <?php if ($server['server_status'] > 0){ ?>
							<td>							
							<a data-toggle="modal" data-target="#buyPort" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-usd"></span> Изменить порт</a>
						  </td>
						  <?php } ?>
						</tr>
						<tr>
							<th>Слоты:</th>
							<td><?php echo $server['server_slots'] ?></td>
							<?php if ($server['server_status'] > 0){ ?>
							<td>							
							<a data-toggle="modal" data-target="#buySlots" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-usd"></span> Изменить</a>
						  </td>
						  <?php } ?>
						</tr>
						<tr>
							<th>Дата окончания оплаты:</th>
							<td><?php echo date("d.m.Y", strtotime($server['server_date_end'])) ?></td>
							<td>
							<a href="/servers/pay/index/<?php echo $server['server_id'] ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-usd"></span><?php if ($server['server_status'] > 0){ ?> Оплатить<?php }else{ ?> Разблокировать<?php } ?></a>
							</td>
						</tr>
						<tr>
							<th>Статус:</th>
							<td>
								<?php if($server['server_status'] == 0): ?> 
								<span class="label label-warning">Заблокирован</span>
								<?php elseif($server['server_status'] == 1): ?> 
								<span class="label label-danger">Выключен</span>
								<?php elseif($server['server_status'] == 2): ?> 
								<span class="label label-success">Включен</span>
								<?php elseif($server['server_status'] == 3): ?> 
								<span class="label label-warning">Установка</span>
								<?php endif; ?> 
							</td>
						</tr>
					</table>
				</div>
				<?php 
				if ($server['server_status'] > 0){
				$output = $ssh2Lib->execute($link, "sudo du -sh /home/gs".$server['server_id']." | awk '{print $1}'");
				?>
				<div class="panel panel-default">
					<div class="panel-heading">FTP доступ</div>
					<table class="table">
						<tr>
							<th>Хост:</th>
							<td><?php echo $server['location_ip'] ?></td>
						</tr>
						<tr>
							<th>Логин:</th>
							<td>gs<?php echo $server['server_id'] ?></td>
						</tr>
						<tr>
							<th>Пароль:</th>
							<td><?php echo $server['server_password'] ?></td>
						</tr>
						<tr>
							<th>Квота:</th>
							<td>
							<?php echo $output ?> / <?php echo $server['server_quota'] ?>M
							<td>
							<?php if ($server['server_quota'] != 50){ ?>
				        <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-info btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'quota50')"><span class="glyphicon glyphicon-refresh"></span> 50 МБ</button>
				      <?php } ?>
				      <?php if ($server['server_quota'] != 150){ ?>  
				        <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-warning btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'quota150')"><span class="glyphicon glyphicon-refresh"></span> 150 МБ</button>
              <?php } ?>
              <?php if ($server['server_quota'] != 300){ ?> 
                <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-danger btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'quota300')"><span class="glyphicon glyphicon-refresh"></span> 300 МБ</button>
              <?php } ?>  
                </td>
							</td>
						</tr>
						<?php if($server['database'] == 0){ ?>
						<tr>
							<th>База Данных:</th>
							<td>
							Неактивна
                <td><button class="btn btn-info btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'createdb')"><span class="glyphicon glyphicon-plus"></span> Активировать MySQL</button></td>
							</td>
						</tr>
						<?php } ?>
					</table>
				</div>
				<?php if($server['database'] == 1):?>
		<div class="panel panel-default">
     <div class="panel-heading">Доступ MySQL</div>
	    <table class="table">
      <tr>
       <th>Хост:</th>
       <td>localhost</td>
      </tr>
      <tr>
       <th>Логин:</th>
       <td>gs<?php echo $server['server_id'] ?></td>
      </tr>
      <tr>
       <th>Пароль:</th>
       <td><?php echo $server['server_password'] ?></td>
      </tr>
      <tr>
       <th>PhpMyAdmin:</th>
       <td><a href="http://ultra-host.ru/myadmin/index.php?pma_username=gs<?php echo $server['server_id'] ?>&pma_password=<?php echo $server['server_password'] ?>&db=gs<?php echo $server['server_id'] ?>">Войти</a></td>
      <td><button class="btn btn-danger btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'delldb')"><span class="glyphicon glyphicon-minus"></span> Отключить MySQL</button></td>
      </tr>
     </table>
    </div>
    <?php endif; ?>
				<h2>Редактирование</h2>
				<form class="form-horizontal" action="#" id="editForm" method="POST">
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-9">
							<div class="checkbox">
								<label><input type="checkbox" id="editpassword" name="editpassword" onChange="togglePassword()"> Изменить пароль</label>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="password" class="col-sm-3 control-label">Пароль:</label>
						<div class="col-sm-4">
							<input type="password" class="form-control" id="password" name="password" placeholder="Введите пароль" disabled>
						</div>
					</div>
					<div class="form-group">
						<label for="password2" class="col-sm-3 control-label">Повтор пароля:</label>
						<div class="col-sm-4">
							<input type="password" class="form-control" id="password2" name="password2" placeholder="Повторите пароль" disabled>
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-9">
							<button type="submit" class="btn btn-primary">Сохранить</button>
						</div>
					</div>
				</form>
				</div>
    
    <div id="ver" class="tab-pane fade">
	<div class="panel panel-default">
					<div class="panel-heading">Сменить версию сервера</div>
 <div class="panel-body">
 <?php if($server['game_query'] == 'samp'): ?>
				<button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-warning btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'svz')"><span class="glyphicon glyphicon-refresh"></span> SA:MP 0.3z</button>
                <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-info btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'svx')"><span class="glyphicon glyphicon-refresh"></span> SA:MP 0.3x</button>	
                <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-success btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'sve')"><span class="glyphicon glyphicon-refresh"></span> SA:MP 0.3e</button>
                <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-primary btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'sv037')"><span class="glyphicon glyphicon-refresh"></span> SA:MP 0.3.7</button>
                <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-danger btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'cve')"><span class="glyphicon glyphicon-refresh"></span> CR:MP 0.3e</button>
				<?php endif; ?>
				</div>
				</div>
				</div>
				<div id="stat" class="tab-pane fade">
				<?php if($server['server_status'] == 2){ ?>
				<div class="panel panel-default">
					<div class="panel-heading">Статистика сервера</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-5">
								<table class="table">
									<?php if($query): ?> 
									<tr>
										<th>Название:</th>
										<td><?php echo $query['hostname'] ?></td>
									</tr>
									<tr>
										<th>Игроки:</th>
										<td><?php echo $query['players'] ?> из <?php echo $query['maxplayers'] ?></td>
									</tr>
									<tr>
										<th>Игровой режим:</th>
										<td><?php echo $query['gamemode'] ?></td>
									</tr>
									<tr>
										<th>Карта:</th>
										<td><?php echo $query['mapname'] ?></td>
									</tr>
									<?php endif; ?>
									<tr>
										<th>Нагрузка CPU</th>
										<td>~ <?php echo $server['server_cpu_load'] ?>%</td>
									</tr>
									<tr>
										<th>Нагрузка RAM</th>
										<td>~ <?php echo $server['server_ram_load'] ?>%</td>
									</tr>
								</table>
							</div>
							<div class="col-md-7">
								<div id="statsGraph" style="height: 220px;"></div>
							</div>
						</div>
					</div>
				</div>
				<?php }else{ echo "<div class='alert alert-danger'><b>Ошибка!</b> Для просмотра статистики сервер должен быть включен.</div>"; } ?>
				</div>
				<div id="config" class="tab-pane fade">
<?php
if($server['game_query'] == 'samp'):
$config = "server.cfg";
endif;
$cfg = file_get_contents('ftp://gs'.$server['server_id'].':'.$server['server_password'].'@'.$server['location_ip'].':21/'.$config.'');
if(isset($_REQUEST['otp'])){
$context = stream_context_create(array('ftp'=>array('overwrite' => true)));
$fopen=fopen('ftp://gs'.$server['server_id'].':'.$server['server_password'].'@'.$server['location_ip'].'/'.$config.'',"w",false,$context);
$fputs=fputs($fopen,$_REQUEST['txt']);
fclose($fopen);
if($fputs):
  echo '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">×</a><b>Выполнено!</b> Вы успешно отредактировали конфигурацию сервера.</div>';
else:
  echo '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">×</a><b>Ошибка!</b> При редактировании конфигурации произошла ошибка.</div>';
endif;
}
?>
				<form name=forma method='POST'>
<div class="form-group">
<div class="panel panel-default">
<div class="panel-heading">Редактор конфигурации</div>
<textarea name=txt class="form-control" rows="20"><?php echo $cfg ?></textarea>
</div>
<button type="submit" name=otp class="btn btn-default">Сохранить</button>
</div>
</form>
				</div>
				
<div id="cmd" class="tab-pane fade">
<?php if($server['server_status'] == 2){ ?>
							<?php
							$output = $ssh2Lib->execute($link, "sudo tail -n 10 /home/gs".$server['server_id']."/server_log.txt");
								if($_POST['cmd_console']):
									require_once('./engine/libs/SampRconAPI.php');
									$cfg = file_get_contents('ftp://gs'.$server['server_id'].':'.$server['server_password'].'@'.$server['location_ip'].':21/server.cfg');
									$pass = explode("\n",$cfg);
									$pass = substr($pass[2], 14);
									$cmd = $_POST['cmd'];
									$server_cmd = new SampRconAPI($server['location_ip'],$server['server_port'], $pass);
									if($server_cmd->isOnline()) $result = $server_cmd->call($cmd);
									
									if(empty($result[0])):
										echo '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">×</a><b>Выполнено!</b> Команда <code>'.$cmd.'</code> успешно отправлена!</div>';
									else:
									  echo '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">×</a><b>Ошибка!</b> При отправке команды <code>'.$cmd.'</code> произошла ошибка!</div>';
									endif;
							  endif;
							?>
							<textarea disabled class="form-control" rows="15" style="color: #fff; background: #000; border: #000;"><?php echo $output; ?></textarea><br/>
							<form role="form" method='POST'>
							  <div class="form-group">
							  <div class="row">
			<div class="col-xs-12 col-md-12 col-lg-12">
				<div class="input-group">
					<span class="input-group-addon">Команда</span>
					<input required type="text" name="cmd" class="form-control" placeholder="Введите команду">
					<span class="input-group-btn">
					  <input type="hidden" name="cmd_console" value="true">
						<button class="btn btn-danger" type="sumbit">Отправить</button>
					</span>
				</div>
		</div>
</form>
</div>
</div>
<?php }else{ echo "<div class='alert alert-danger'><b>Ошибка!</b> Сервер выключен, консоль недоступна.</div>"; } ?>
</div>
				
				<div class="modal fade" id="buySlots" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
					<div class="modal-content">
					  <div class="modal-header">
						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<h4 class="modal-title" id="myModalLabel">Изменение количества слотов</h4>
					  </div>
					  <div class="modal-body">
						<form class="form-horizontal" action="#" id="slotsForm" method="POST">
							<div class="form-group">
								<label for="slots" class="col-sm-5 control-label">Количество слотов:</label>
								<div class="col-sm-4">
									<div class="input-group">
									  <span class="input-group-btn"><button class="btn btn-default" type="button" onClick="minusSlots()">-</button></span>
										<input type="text" class="form-control" id="slots" name="slots" value="<?php echo $server['server_slots'] ?>">
										<span class="input-group-btn"><button class="btn btn-default" type="button" onClick="plusSlots()">+</button></span>
									</div>
								</div>
							</div>
							<div class="sum">
							<span class="total">Итого: <strong id="price">0.00 руб.</strong></span>
							</div>
							<input type="hidden" name="buy_slots" value="true">
							<center><button type="submit" class="btn btn-success btn-sm">Оплатить</button></center>
						</form>
					  </div>
					</div>
				  </div>
				</div>
				<div class="modal fade" id="buyPort" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				  <div class="modal-dialog">
					<div class="modal-content">
					  <div class="modal-header">
						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<h4 class="modal-title" id="myModalLabel">Изменение порта</h4>
					  </div>
					  <div class="modal-body">
						<form class="form-horizontal" action="#" id="portForm" method="POST">
							<div class="form-group">
								<label for="port" class="col-sm-5 control-label">Новый порт:</label>
								<div class="col-sm-4">
									<div class="input-group">
									  <span class="input-group-btn"><button class="btn btn-default" type="button" onClick="minusPort()">-</button></span>
										<input type="text" class="form-control" id="port" name="port" value="<?php echo $server['server_port'] ?>">
										<span class="input-group-btn"><button class="btn btn-default" type="button" onClick="plusPort()">+</button></span>
									</div>
								</div>
							</div>
							<div class="sum">
							<span class="total">Итого: <strong id="price_port">0.00 руб.</strong></span>
							</div>
							<h6>* Стоимость смены порта составляет 100р.</h6>
							<input type="hidden" name="buy_port" value="true">
							<center><button type="submit" class="btn btn-success btn-sm">Оплатить</button></center>
						</form>
					  </div>
					</div>
				  </div>
				</div>
				<?php } ?>
				<script>
				function updateForm(promo) {
						var gamePrice = '<?=$gamePrice?>';
						var sslots = '<?=$server['server_slots']?>';
						var slots = $("#slots").val();
						if(sslots == slots){
							var price = 0;
						} else {
							if(slots-sslots <= 0) {
								var price = 0;
							} else {
								var price = gamePrice * (slots-sslots);
							}
						}
						
						$('#price').text(price.toFixed(2) + ' руб.');
					}
					function updatePort() {
					var port = '<?=$server['server_port']?>';
						var nport = $("#port").val();
						if(port != nport){
						var price_port = 100;
						} else {
						var price_port = 0;
						}
						
						$('#price_port').text(price_port.toFixed(2) + ' руб.');
					}
				function plusSlots() {
						value = parseInt($('#slots').val());
						$('#slots').val(value+1);
						updateForm();
					}
				function minusSlots() {
						value = parseInt($('#slots').val());
						$('#slots').val(value-1);
						updateForm();
					}
				function plusPort() {
						value = parseInt($('#port').val());
						$('#port').val(value+1);
						updatePort();
					}
				function minusPort() {
						value = parseInt($('#port').val());
						$('#port').val(value-1);
						updatePort();
					}
					$('#editForm').ajaxForm({ 
						url: '/servers/control/ajax/<?php echo $server["server_id"] ?>',
						dataType: 'text',
						success: function(data) {
							console.log(data);
							data = $.parseJSON(data);
							switch(data.status) {
								case 'error':
									showError(data.error);
									break;
								case 'success':
									showSuccess(data.success);
									setTimeout("reload()", 1500);
									break;
							}
							$('button[type=submit]').prop('disabled', false);
						},
						beforeSubmit: function(arr, $form, options) {
							$('button[type=submit]').prop('disabled', true);
						}
					});
					function togglePassword() {
						var status = $('#editpassword').is(':checked');
						if(status) {
							$('#password').prop('disabled', false);
							$('#password2').prop('disabled', false);
						} else {
							$('#password').prop('disabled', true);
							$('#password2').prop('disabled', true);
						}
					}
					var serverStats = [
						<?php foreach($stats as $item): ?> 
						[<?php echo strtotime($item['server_stats_date'])*1000 ?>, <?php echo $item['server_stats_players'] ?>],
						<?php endforeach; ?> 
					];
					$.plot($("#statsGraph"), [serverStats], {
						xaxis: {
							mode: "time",
							timeformat: "%H:%M"
						},
						yaxis: {
							min: 0,
							max: <?php echo $server['server_slots'] ?>
						},
						series: {
							lines: {
								show: true,
								fill: true
							},
							points: {
								show: true
							}
						},
						grid: {
							borderWidth: 0
						},
						colors: [ "#428BCA" ]
					});
					
					function sendAction(serverid, action) {
						switch(action) {
							case "reinstall":
							{
								if(!confirm("Вы уверенны в том, что хотите переустановить сервер? Все данные будут удалены.")) return;
								break;
							}
							case "svz":
							{
								if(!confirm("Вы уверенны в том, что хотите изменить версию сервера на SA:MP 0.3z? Сервер будет переустановлен.")) return;
								break;
							}
							case "svx":
							{
								if(!confirm("Вы уверенны в том, что хотите изменить версию сервера на SA:MP 0.3x? Сервер будет переустановлен.")) return;
								break;
							}
							case "sve":
							{
								if(!confirm("Вы уверенны в том, что хотите изменить версию сервера на SA:MP 0.3e? Сервер будет переустановлен.")) return;
								break;
							}
							case "sv037":
							{
								if(!confirm("Вы уверенны в том, что хотите изменить версию сервера на SA:MP 0.3.7? Сервер будет переустановлен.")) return;
								break;
							}
							case "cve":
							{
								if(!confirm("Вы уверенны в том, что хотите изменить версию сервера на CR:MP 0.3e? Сервер будет переустановлен.")) return;
								break;
							}
							case "delldb":
							{
								if(!confirm("Вы уверенны в том, что хотите отключить базу данных? Все записи и таблицы будут удалены.")) return;
								break;
							}
							case "quota50":
							{
								if(!confirm("Вы уверенны в том, что хотите установить дисковую квоту 50 МБ?")) return;
								break;
							}
							case "quota150":
							{
								if(!confirm("Эта услуга будет стоить вам 7.50 руб. Вы уверены в том, что хотите заказать её?")) return;
								break;
							}
							case "quota300":
							{
								if(!confirm("Эта услуга будет стоить вам 15 руб. Вы уверены в том, что хотите заказать её?")) return;
								break;
							}
							case "backup":
							{
								if(!confirm("Вы уверены в том, что хотите сделать бэкап сервера? Прежний бэкап будет удален.")) return;
								break;
							}
							case "unbackup":
							{
								if(!confirm("Вы уверены в том, что хотите восстановить сервер?")) return;
								break;
							}
						}
						$.ajax({ 
							url: '/servers/control/action/'+serverid+'/'+action,
							dataType: 'text',
							success: function(data) {
								console.log(data);
								data = $.parseJSON(data);
								switch(data.status) {
									case 'error':
										showError(data.error);
										$('#controlBtns button').prop('disabled', false);
										break;
									case 'success':
										showSuccess(data.success);
										setTimeout("reload()", 1500);
										break;
								}
							},
							beforeSend: function(arr, options) {
								if(action == "reinstall") showWarning("Сервер будет переустановлен в течении 10 секунд!");
								if(action == "start") showWarning("Сервер запускается! Пожалуйста, подождите некоторое время.");
								if(action == "stop") showWarning("Сервер выключится через 10 секунд! Пожалуйста, подождите.");
								if(action == "restart") showWarning("Сервер перезапускается! Пожалуйста, подождите некоторое время.");
								if(action == "backup") showWarning("Создается BackUp Сервера! Пожалуйста, подождите некоторое время.");
								$('#controlBtns button').prop('disabled', true);
							}
						});
					}
				</script>
<?php $ssh2Lib->disconnect($link); ?>
<?php echo $footer ?>
