<?php
/*
* @Слито RAG20
*/
?>
<?php echo $header ?>
				<div class="page-header">
					<h1>Заказать сервер</h1>
				</div>
				<form class="form-horizontal" action="#" id="orderForm" method="POST">
					<h3>Основная информация</h3>
					<div class="form-group">
						<label for="game" class="col-sm-3 control-label">Игра:</label>
						<div class="col-sm-5">
							<select class="form-control" id="gameid" name="gameid" onChange="updateForm()">
								<?php foreach($games as $item): ?> 
								<option value="<?php echo $item['game_id'] ?>"><?php echo $item['game_name'] ?></option>
								<?php endforeach; ?> 
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="location" class="col-sm-3 control-label">Локация:</label>
						<div class="col-sm-5">
							<select class="form-control" id="locationid" name="locationid">
								<?php foreach($locations as $item): ?> 
								<option value="<?php echo $item['location_id'] ?>"><?php echo $item['location_name'] ?></option>
								<?php endforeach; ?> 
							</select>
						</div>
					</div>
					<h3>Дополнительная информация</h3>
					<div class="form-group">
						<label for="months" class="col-sm-3 control-label">Период оплаты:</label>
						<div class="col-sm-3">
							<select class="form-control" id="months" name="months" onChange="updateForm()">
								<option value="1">1 месяц</option>
								<option value="3">3 месяца (-5%)</option>
								<option value="6">6 месяцев (-10%)</option>
								<option value="12">12 месяцев (-15%)</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="months" class="col-sm-3 control-label">Нужен вам MySQL?</label>
						<div class="col-sm-3">
							<select class="form-control" id="months" name="mysql" onChange="updateForm()">
								<option value="1">Да</option>
								<option value="0">Нет</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<label for="months" class="col-sm-3 control-label">Количество слотов:</label>
						<div class="col-sm-2">
							<div class="input-group">
								<span class="input-group-btn"><button class="btn btn-default" type="button" onClick="minusSlots()">-</button></span>
								<input type="text" class="form-control" id="slots" name="slots">
								<span class="input-group-btn"><button class="btn btn-default" type="button" onClick="plusSlots()">+</button></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="quota" class="col-sm-3 control-label">Место на сервере</label>
						<div class="col-sm-3">
							<select class="form-control" id="quota" name="quota" onChange="updateForm()">
								<option value="50">50 МБ</option>
								<option value="150">150 МБ</option>
								<option value="300">300 МБ</option>
							</select>
						</div>
					</div>
					<h3>Стоимость</h3>
					<div class="form-group">
						<label for="promo" class="col-sm-3 control-label"><span title='Купон для скидки.'>Купон (не обязательно):</span></label>
						<div class="col-sm-4">
							<input type="promo" class="form-control" onChange="promoCode()" id="promo" name="promo" placeholder="Введите купон">
						</div>
					</div>
					<div class="form-group">
						<label for="price" class="col-sm-3 control-label">Итого:</label>
						<div class="col-sm-5">
							<p class="lead" id="price">0.00 руб.</p>
						</div>
					</div>
					<div class="form-group">
					<input type="hidden" name="password" id="password" value="<?=substr(md5(rand(5333, 23244)), 0, 10)?>">
						<div class="col-sm-offset-3 col-sm-9">
							<button type="submit" class="btn btn-primary">Заказать</button>
						</div>
					</div>
				</form>
				<script>
					var gameData = {
					<?php foreach($games as $item): ?> 
						<?php echo $item['game_id'] ?>: {
							'minslots': <?php echo $item['game_min_slots'] ?>,
							'maxslots': <?php echo $item['game_max_slots'] ?>,
							'price': <?php echo $item['game_price'] ?>
						},
					<?php endforeach; ?> 
					};
					
					$('#orderForm').ajaxForm({ 
						url: '/servers/order/ajax',
						dataType: 'text',
						success: function(data) {
							console.log(data);
							data = $.parseJSON(data);
							switch(data.status) {
								case 'error':
									showError(data.error);
									$('button[type=submit]').prop('disabled', false);
									break;
								case 'success':
									showSuccess(data.success);
									setTimeout("redirect('/servers/control/index/" + data.id + "')", 1500);
									break;
							}
						},
						beforeSubmit: function(arr, $form, options) {
							$('button[type=submit]').prop('disabled', true);
							showWarning("Проверяем параметра сервера и счёта");
						}
					});
					
					$(document).ready(function() {
						updateForm();
					});
					
					function promoCode(){
						var promo = $("#promo").val();
						$.post("/servers/order/promo",{code: promo},function(data){
							data = $.parseJSON(data);
							switch(data.status) {
								case 'error':
									showError(data.error);
									updateForm();
									break;
								case 'success':
									showSuccess(data.success);
									updateForm(data.skidka);
									break;
							}
						});
						
					}
					
					function updateForm(promo) {
						var gameID = $("#gameid option:selected").val();
						var slots = $("#slots").val();
						if(slots < gameData[gameID]['minslots']) {
							slots = gameData[gameID]['minslots'];
							$("#slots").val(slots);
						}
						if(slots > gameData[gameID]['maxslots']) {
							slots = gameData[gameID]['maxslots'];
							$("#slots").val(slots);
						}
						var price = gameData[gameID]['price'] * slots;
						var months = $("#months option:selected").val();
						var quota = $("#quota option:selected").val();
						switch(quota) {
						  case "50":
								quota = 0;
								break;
							case "150":
								quota = 7.5;
								break;
							case "300":
								quota = 15;
								break;
						}
						switch(months) {
						  case "1":
								price = 1 * price + quota;
								break;
							case "3":
								price = 3 * price * 0.95 + quota * 0.95;
								break;
							case "6":
								price = 6 * price * 0.90 + quota * 0.90;
								break;
							case "12":
								price = 12 * price * 0.85 + quota * 0.85;
								break;
						}

						if(promo != null){price = price * promo;}
						
						$('#price').text(price.toFixed(2) + ' руб.');
					}
					
					function plusSlots() {
						value = parseInt($('#slots').val());
						$('#slots').val(value+1);
						updateForm();
					}
					function minusSlots() {
						value = parseInt($('#slots').val());
						$('#slots').val(value-1);
						updateForm();
					}
				</script>
<?php echo $footer ?>
