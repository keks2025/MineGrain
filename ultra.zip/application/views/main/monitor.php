<?php echo $header ?>
<ul class="breadcrumb">
					<li><i class="glyphicon glyphicon-home"></i> <a href="/">Главная</a> <span class="divider"></span></li>
					<li class="active">Мониторинг</li>
				</ul>


<div alt="Мониторинг" style="font-size:12px; margin-top:0px;">
    <table class="table table-bordered">
        <thead>
							<th>ID</th>
							<th>Игра</th>
							<th>Название</th>
							<th>Игроки</th>
							<th>Карта</th>
							<th>Локация</th>
							<th>IP</th>
            </tr>
        </thead>
       <tbody>
						<?php foreach($servers as $item): ?> 

<? if (!($item['server_status'] == 2)) { // пропуск нечетных чисел
                        continue;
                        }?>
						<tr>

							<?php if($item['server_status'] == 2) {
									$queryLib = new queryLibrary($item['game_query']);
									$queryLib->connect($item['location_ip'], $item['server_port']);
									$q = $queryLib->getInfo();
									$queryLib->disconnect();
								} ?>	
								
							<td>№<?php echo $item['server_id'] ?></td>
							<td><?php echo $item['game_name']; ?></td>
                                                        <td><?if($item['game_query'] == 'samp' or $item['game_query'] == 'mtasa'){ $str2 = iconv ('windows-1251', 'utf-8', $q['hostname']); echo $str2;}else{ echo $q['hostname']; }?></td>
							<td> <div style="position: relative;"> <div class="progress progress-striped" style="margin-bottom: 0px;"> <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $q['players']*100/$q['maxplayers'] ?>%"></div> <div style="position: absolute;width: 100%;"><center><?php echo $q['players'] ?>/<?php echo $q['maxplayers'] ?></center></div> </div></div> </center></td>
                                                        <td><?if($item['game_query'] == 'samp' or $item['game_query'] == 'mtasa'){ $str2 = iconv ('windows-1251', 'utf-8', $q['mapname']); echo $str2;}else{ echo $q['mapname']; }?></td>
							<td><?php echo $item['location_name'] ?></td>
							<td><?php echo $item['location_ip2'] ?>:<?php echo $item['server_port'] ?></td>
						<?php endforeach; ?> 
					</tbody>
    </table>
<?php echo $pagination ?> 
<?php echo $footer ?>