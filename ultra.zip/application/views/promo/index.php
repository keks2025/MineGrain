<?php echo $header ?>
<h3 class="box-title">Купон</h3><br>
<div class="panel panel-warning">
<div class="panel-heading">Текущий купон</div>
<table class="table">
<?php
                // SQL-запрос
	$strSQL = "SELECT * FROM promo ORDER BY `id` DESC limit 1";

	// Выполнить запрос (набор данных $rs содержит результат)
	$rs = mysql_query($strSQL);
	$num = mysql_num_rows($rs);
	
	// Цикл по recordset $rs
	// Каждый ряд становится массивом ($row) с помощью функции mysql_fetch_array
	while($row = mysql_fetch_array($rs)) {

	   // Записать значение столбца (который является теперь массивом $row)
	  echo "<tr><th>Купон:</th><td>" . $row['cod'] . "</td></tr>";
	  echo "<tr><th>Использования:</th><td>" . $row['used'] . "/" . $row['replace'] . " раз(а)</td></tr>";
	  echo "<tr><th>Скидка:</th><td>" . $row['skidka'] . "%</td></tr>";
	  echo "<tr><th>Статус:</th><td>";
	  if($row['replace'] <= $row['used']){
	  echo "<span class='label label-danger'>Не активен</span>";
	  }else{
	  echo "<span class='label label-success'>Активен</span>";
	  }
	  }
	  if ($num==0){
	  echo "<tr><td colspan='5' style='text-align: center;'>На данный момент нет купонов.</td></tr>";
	  }
?>
</tr>
</td>
</table>
</div>
<?php echo $footer ?>