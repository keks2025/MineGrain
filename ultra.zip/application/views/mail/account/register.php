<?php
/*
* @LitePanel 3.0.1
* @Developed by Dominator!?
*/
?>
Здравствуйте, <?php echo $lastname ?> <?php echo $firstname ?>!

Благодарим Вас за регистрацию на сайте игрового хостинга Ultra-Host! Мы благодарны Вам за то, что Вы выбрали именно нашу хостинг-компанию!

Данные для входа в систему:
E-Mail: <?php echo $email ?> 
Пароль: <?php echo $password ?> 

С уважением,
Администрация Ultra-Host!
