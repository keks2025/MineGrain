<?php
/*
* @Слито RAG20
*/
?>
Здравствуйте, <?php echo $lastname ?> <?php echo $firstname ?>!

Уведомляем Вас о том, что в тикете #<?php echo $ticketid ?> появилось новое сообщение.

С уважением,
Администрация Ultra-Host!
