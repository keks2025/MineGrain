<?php echo $header ?>
<h3 class="box-title">Оферта</h3><br>
<div class="panel-group" id="collapse-group">
 <div class="panel panel-default">
 <div class="panel-heading">
 <h4 class="panel-title">
 <a data-toggle="collapse" data-parent="#collapse-group" href="#el1">Общее</a>
 </h4>
 </div>
 <div id="el1" class="panel-collapse collapse">
 <div class="panel-body">1.1. Администрация в праве изменять данные правила без уведомления клиентов.<br>
				1.2. Администрация в праве остановить оказание услуг за нарушение данных правил.<br>
				1.3. Использование клиентом услуги не должно нарушать законодательство Российской Федерации.</div>
 </div>
 </div>
 <div class="panel panel-default">
 <div class="panel-heading">
 <h4 class="panel-title">
 <a data-toggle="collapse" data-parent="#collapse-group" href="#el2">Игровые сервера</a>
 </h4>
 </div>
 <div id="el2" class="panel-collapse collapse">
 <div class="panel-body">1.4. Запрещено использование дискового пространства сервера для хранения содержимого, не относящегося к игровому серверу.<br>
				1.5. Запрещено устанавливать параметры сервера, не соответствующие реальным параметрам, а именно: IP, порты, слоты, tickrate.<br>
				1.6. Запрещено использовать неофициальные исполняемые файлы игрового сервера.<br>
				1.7. Запрещено использовать параметры игрового сервера, которые создают нагрузку на ЦП выше 10% от одного ядра.</div>
 </div>
 </div>
 <div class="panel panel-default">
 <div class="panel-heading">
 <h4 class="panel-title">
 <a data-toggle="collapse" data-parent="#collapse-group" href="#el3">Финансы</a>
 </h4>
 </div>
 <div id="el3" class="panel-collapse collapse">
 <div class="panel-body">1.8. Вывод неиспользованного остатка средств из биллинга невозможен.<br>
				1.9. Комиссия за все финансовые операции между администрацией и клиентом возлагается на клиента.<br>
				2.0. После окончания оплаченного периода, предоставление услуги останавливается, через 3 дня все данные безвозвратно удаляются.</div>
 </div>
 </div>
</div>
<?php echo $footer ?>