<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="keywords" content="game hosting, game servers,free game hosting,free samp hosting,бесплатный игровой хостинг,бесплатный хостинг серверов самп,получить игровой сервер бесплатно">
  <meta name="description" content="Ultra Host - Дешёвый хостинг игровых серверов SA:MP.">
	
	<title>Ultra Host | Восстановление</title>
    
    <link href="/application/public/css/main.css" rel="stylesheet">
	<link href="/application/public/css/bootstrap.min.css" rel="stylesheet">
	<!--link href="/application/public/css/bootstrap-theme.min.css" rel="stylesheet"-->
	
	<script src="/application/public/js/jquery.min.js"></script>
	<script src="/application/public/js/jquery.form.min.js"></script>
	<script src="/application/public/js/bootstrap.min.js"></script>
	<script src="/application/public/js/main.js"></script>
	
	<script type="text/javascript" src="https://www.google.com/jsapi"></script>
	<link rel="stylesheet" type="text/css" href="/application/public/css/jquery.gritter.css" />
	<script type="text/javascript" src="/application/public/js/jquery.gritter.js"></script>
	
	<style>
		body {
			padding-top: 72px;
			padding-bottom: 40px;
			background: url(/application/public/img/authbg.jpg) no-repeat;
		}
	</style>
<script>
$(document).ready(function(){
  $("body").css("display","none").fadeIn("slow");
});
</script>
</head>
<body>
	<!-- Powered by LitePanel -->
	<div id="content" class="container">
		 
		 
		 
		<form class="form-signin" id="restoreForm" action="#" method="POST">
			<h2 class="form-signin-heading">Восставновление</h2>
			<input type="text" class="form-control" id="email" name="email" placeholder="E-Mail">
			<div class="form-control captcha">
				<img src="/main/captcha">
			</div>
			<input type="text" class="form-control" id="captcha" name="captcha" placeholder="Проверочный код">
			<button class="btn btn-lg btn-primary btn-block" type="submit">Восстановить</button>
			<div class="other-link"><a href="/account/login">Вернуться к Авторизации</a></div>
		</form>
		<script>
		$.gritter.add({
	title: 'Привет ;)',
	text: 'Чтобы заказать наши услуги, пожалуйста, зарегистрируйтесь или войдите в свой аккаунт на нашем сайте!'//,
	// class_name: 'gritter-light'
});
			$('#restoreForm').ajaxForm({ 
				url: '/account/restore/ajax',
				dataType: 'text',
				success: function(data) {
					console.log(data);
					data = $.parseJSON(data);
					switch(data.status) {
						case 'error':
							showError(data.error);
							reloadImage('#captchaimage');
							$('button[type=submit]').prop('disabled', false);
							break;
						case 'success':
							showSuccess(data.success);
							break;
					}
				},
				beforeSubmit: function(arr, $form, options) {
					$('button[type=submit]').prop('disabled', true);
				}
			});
			$('.captcha img').click(function() {
				reloadImage(this);
			});
		</script>
	</div>
    <!-- /Powered by LitePanel -->
<!--LiveInternet counter--><script type="text/javascript"><!--
document.write("<a href='//www.liveinternet.ru/click' "+
"target=_blank><img src='//counter.yadro.ru/hit?t26.6;r"+
escape(document.referrer)+((typeof(screen)=="undefined")?"":
";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?
screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+
";"+Math.random()+
"' alt='' title='LiveInternet: показано число посетителей за"+
" сегодня' "+
"border='0' width='88' height='15'><\/a>")
//--></script><!--/LiveInternet-->
</body>
</html>