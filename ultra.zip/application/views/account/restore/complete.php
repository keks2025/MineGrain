<?php
/*
* @LitePanel
* @Слил RAG20
*/
?>
<?php echo $loginheader ?>
		<div class="form-signin">
			<h2 class="form-signin-heading">Восставновление</h2>
			<p class="lead">Новый пароль: <strong><?php echo $password ?></strong></p>
			<p class="text-center text-muted">Уважаемый клиент, мы не рекомендуем использовать данный пароль для постоянного использования. Не забудьте сменить пароль сразу после авторизации.</p>
			<div class="other-link"><a href="/account/login">Авторизироваться</a></div>
		</form>
<?php echo $loginfooter ?>
