<?php echo $header ?>
<?php
$userreferals = mysql_query("SELECT * FROM users WHERE `user_refid` = '".$_SESSION['user_id']."'");
$userreferalscount = mysql_num_rows( $userreferals);
$usrv = mysql_query("SELECT * FROM `users` WHERE `user_id` = '".$_SESSION['user_id']."'");
$usrv_r = mysql_fetch_array($usrv);
$refv = mysql_query("SELECT * FROM `users` WHERE `user_id` = '".$usrv_r['user_refid']."'");
$refv_r = mysql_fetch_array($refv);
?>
<div class="page-header">
					<h1>Реферальная программа</h1>
				</div>
<form class="form-horizontal" action="" method="post">
<div class="alert alert-info">За каждого нового клиента, которого вы пригласите, вы будете получать 10% от суммы его пополнений.</div>
<div class="panel panel-danger">
					<div class="panel-heading">Информация о рефералах</div>
					<table class="table">
						<tr>
							<th>Вы привели:</th>
							<td><?php echo $userreferalscount ?> рефералов</td>
						</tr>
						<tr>
							<th>Заработано:</th>
							<td><?php echo $usrv_r['user_refmoney'] ?> рублей</td>
						</tr>
						<tr>
							<th>Ваш рефер:</th>
							<td>
							<?php 
							if($usrv_r['user_refid']==0){
							echo "У вас нет рефера.";
							}else{
							echo "".$refv_r['user_firstname']." ".$refv_r['user_lastname']."";
							}
							?>
							</td>
						</tr>
					</table>
				</div>			
				<h3>Ссылки для привлечения</h3>
						<div class="form-group">
						<label class="col-sm-3 control-label">Уникальная ссылка:</label>
						<div class="col-sm-5">
							<input type="text" class="form-control" value="http://<?php echo $_SERVER['HTTP_HOST'] ?>/account/register?refid=<?=$_SESSION['user_id']?>">
						</div>
					</div>
					</form>
<?php echo $footer ?>