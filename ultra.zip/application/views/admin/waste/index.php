<?php
/*
* @Слито RAG20
*/
?>
<?php echo $header ?>
				<div class="page-header">
					<h1>Все расходы</h1>
				</div>
				<table class="table table-striped">
					<thead>
						<tr>
							<th>ID</th>
							<th>Статус</th>
							<th>Пользователь</th>
							<th>Сумма</th>
							<th>Услуга</th>
							<th>Дата создания</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($waste as $item): ?> 
						<tr>
							<td>#<?php echo $item['waste_id'] ?></td>
							<td>
								<?php if($item['waste_status'] == 1): ?> 
								<span class="label label-success">Списано</span>
								<?php endif; ?> 
							</td>
							<td><?php echo $item['user_firstname'] ?> <?php echo $item['user_lastname'] ?></td>
							<td><?php echo $item['waste_ammount'] ?> руб.</td>
							<td><?php echo $item['waste_usluga'] ?></td>
							<td><?php echo date("d.m.Y в H:i", strtotime($item['waste_date_add'])) ?></td>
						</tr>
						<?php endforeach; ?> 
						<?php if(empty($waste)): ?> 
						<tr>
							<td colspan="6" style="text-align: center;">На данный момент нет расходов.</td>
						<tr>
						<?php endif; ?> 
					</tbody>
				</table>
				<?php echo $pagination ?> 
<?php echo $footer ?>
