<?php
//Если переменная Name передана
if (isset($_POST["createpromo"])) {
    //Вставляем данные, подставляя их в запрос
    $sql = mysql_query("INSERT INTO `promo` (`id`, `cod`, `replace`, `used`, `skidka`) 
                        VALUES ('NULL','".$_POST['cod']."','".$_POST['replace']."','0','".$_POST['skidka']."')");
    //Если вставка прошла успешно
    if ($sql) {
        $msg = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">×</a><b>Выполнено!</b> Купон на скидку '.$_POST["skidka"].'% успешно добавлен.</div>';
    } else {
        $msg = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">×</a><b>Ошибка!</b> При добавлении купона '.$_POST["cod"].' произошла ошибка.</div>';
    }
}
?>
<?php echo $header ?>
<?if(!empty($msg)):?><?=$msg?><?endif;?>
<div class="page-header">
					<h1>Создание купона</h1>
				</div>
				<form class="form-horizontal" action="" method="post">
					<h3>Основная информация</h3>
					<div class="form-group">
						<label for="cod" class="col-sm-3 control-label">Купон:</label>
						<div class="col-sm-4">
							<input type="text" required class="form-control" name="cod" placeholder="Введите код купона" onkeyup="this.value=this.value.replace(/\s+/gi,'')">
						</div>
					</div>
					<div class="form-group">
						<label for="replace" class="col-sm-3 control-label">Количество использований:</label>
						<div class="col-sm-4">
							<input type="number" min="1" required class="form-control" name="replace" placeholder="Введите количество раз">
						</div>
					</div>
					<div class="form-group">
						<label for="skidka" class="col-sm-3 control-label">Скидка:</label>
						<div class="col-sm-4">
							<input type="number" min="1" max="100" required class="form-control" name="skidka" placeholder="Введите скидку (в процентах)">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-9">
							<button type="submit" class="btn btn-primary" name="createpromo">Создать</button>
						</div>
					</div>
					</form>
<?php echo $footer ?>