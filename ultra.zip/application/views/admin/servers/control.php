<?php
/*
* @Слито RAG20
*/
require_once('./engine/libs/ssh2.php');
$ssh2Lib = new ssh2Library();
$link = $ssh2Lib->connect($server['location_ip'], $server['location_user'], $server['location_password']);
?>
<?php echo $header ?>
<?if(!empty($msg)):?><?=$msg?><?endif;?>
				<div class="page-header">
					<h1>Управление сервером</h1>
				</div>
				<?php if ($server['server_status'] > 0){ ?>
				<ul class="nav nav-tabs">
  <li class="active"><a data-toggle="tab" href="#server"><span class="glyphicon glyphicon-hdd"></span> Сервер</a></li>
  <li><a data-toggle="tab" href="#ver"><span class="glyphicon glyphicon-refresh"></span> Версия</a></li>
  <li><a data-toggle="tab" href="#stat"><span class="glyphicon glyphicon-globe"></span> Статистика</a></li>
  <li><a data-toggle="tab" href="#cmd"><span class="glyphicon glyphicon-barcode"></span> Консоль</a></li>
  <li><a data-toggle="tab" href="#config"><span class="glyphicon glyphicon-file"></span> Редактор</a></li>
</ul><br/>
<?php } ?>
<div class="tab-content">
  <div id="server" class="tab-pane fade in active">
				<div class="panel panel-success">
					<div class="panel-heading">Информация о сервере</div>
					<table class="table table-bordered">
					<th width="200px" rowspan="20">
								<div align="Center"><img src="<?php echo $server['image_url']?>" style="width:160px; margin-bottom:5px;"></div>
								<?php if($server['server_status'] == 1): ?> 
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-success" onClick="sendAction(<?php echo $server['server_id'] ?>,'start')"><span class="glyphicon glyphicon-off"></span> Включить</button>
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-warning" onClick="sendAction(<?php echo $server['server_id'] ?>,'reinstall')"><span class="glyphicon glyphicon-refresh"></span> Переустановить</button>
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-warning" onClick="sendAction(<?php echo $server['server_id'] ?>,'baned')"><span class="glyphicon glyphicon-lock"></span> Блокировать</button>
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-danger" onClick="sendAction(<?php echo $server['server_id'] ?>,'delete')"><span class="glyphicon glyphicon-trash"></span> Удалить</button>
								<?php elseif($server['server_status'] == 2): ?> 
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-danger" onClick="sendAction(<?php echo $server['server_id'] ?>,'stop')"><span class="glyphicon glyphicon-off"></span> Выключить</button>
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-info" onClick="sendAction(<?php echo $server['server_id'] ?>,'restart')"><span class="glyphicon glyphicon-refresh"></span> Перезапустить</button>
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-warning" onClick="sendAction(<?php echo $server['server_id'] ?>,'baned')"><span class="glyphicon glyphicon-lock"></span> Блокировать</button>
								<?php elseif($server['server_status'] == 0): ?>
								<button style="width: 100%;margin-bottom: 5px;" type="button" class="btn btn-warning" onClick="sendAction(<?php echo $server['server_id'] ?>,'baned')"><span class="glyphicon glyphicon-lock"></span> Разблокировать</button>
								<?php endif; ?>
							</th>
						<tr>
							<th>Игра:</th>
							<td><?php echo $server['game_name'] ?></td>
						</tr>
						<tr>
							<th>Локация:</th>
							<td><?php echo $server['location_name'] ?></td>
						</tr>
						<tr>
							<th>Адрес:</th>
							<td><?php echo $server['location_ip'] ?>:<?php echo $server['server_port'] ?></td>
						</tr>
						<tr>
							<th>Слоты:</th>
							<td><?php echo $server['server_slots'] ?></td>
						</tr>
						<tr>
							<th>Владелец:</th>
							<td><a href="/admin/users/edit/index/<?php echo $server['user_id'] ?>"><?php echo $server['user_firstname'] ?> <?php echo $server['user_lastname'] ?></a></td>
						</tr>
						<tr>
							<th>Дата окончания оплаты:</th>
							<td><?php echo date("d.m.Y", strtotime($server['server_date_end'])) ?></td>
						</tr>
						<tr>
							<th>Статус:</th>
							<td>
								<?php if($server['server_status'] == 0): ?> 
								<span class="label label-warning">Заблокирован</span>
								<?php elseif($server['server_status'] == 1): ?> 
								<span class="label label-danger">Выключен</span>
								<?php elseif($server['server_status'] == 2): ?> 
								<span class="label label-success">Включен</span>
								<?php elseif($server['server_status'] == 3): ?> 
								<span class="label label-warning">Установка</span>
								<?php endif; ?> 
							</td>
						</tr>
					</table>
				</div>
				<?php 
				if ($server['server_status'] > 0){
				$output = $ssh2Lib->execute($link, "sudo du -sh /home/gs".$server['server_id']." | awk '{print $1}'");
				?>
				<div class="panel panel-default">
					<div class="panel-heading">FTP доступ</div>
					<table class="table">
						<tr>
							<th>Хост:</th>
							<td><?php echo $server['location_ip'] ?></td>
						</tr>
						<tr>
							<th>Логин:</th>
							<td>gs<?php echo $server['server_id'] ?></td>
						</tr>
						<tr>
							<th>Пароль:</th>
							<td><?php echo $server['server_password'] ?></td>
						</tr>
						<tr>
							<th>Квота:</th>
							<td>
							<?php echo $output ?> / <?php echo $server['server_quota'] ?>M
							<td>
							<?php if ($server['server_quota'] != 50){ ?>
				        <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-info btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'quota50')"><span class="glyphicon glyphicon-refresh"></span> 50 МБ</button>
				      <?php } ?>
				      <?php if ($server['server_quota'] != 150){ ?>  
				        <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-warning btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'quota150')"><span class="glyphicon glyphicon-refresh"></span> 150 МБ</button>
              <?php } ?>
              <?php if ($server['server_quota'] != 300){ ?> 
                <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-danger btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'quota300')"><span class="glyphicon glyphicon-refresh"></span> 300 МБ</button>
              <?php } ?>
                </td>
							</td>
						</tr>
						<?php if($server['database'] == 0){ ?>
						<tr>
							<th>База Данных:</th>
							<td>
							Неактивна
                <td><button class="btn btn-info btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'createdb')"><span class="glyphicon glyphicon-plus"></span> Активировать MySQL</button></td>
							</td>
						</tr>
						<?php } ?>
					</table>
				</div>
				
				<?php if($server['database'] == 1):?>
		<div class="panel panel-default">
     <div class="panel-heading">Доступ MySQL</div>
	    <table class="table">
      <tr>
       <th>Хост:</th>
       <td>localhost</td>
      </tr>
      <tr>
       <th>Логин:</th>
       <td>gs<?php echo $server['server_id'] ?></td>
      </tr>
      <tr>
       <th>Пароль:</th>
       <td><?php echo $server['server_password'] ?></td>
      </tr>
      <tr>
       <th>PhpMyAdmin:</th>
       <td><a href="http://ultra-host.ru/myadmin/index.php?pma_username=gs<?php echo $server['server_id'] ?>&pma_password=<?php echo $server['server_password'] ?>&db=gs<?php echo $server['server_id'] ?>">Войти</a></td>
      <td><button class="btn btn-danger btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'delldb')"><span class="glyphicon glyphicon-minus"></span> Отключить MySQL</button></td>
      </tr>
     </table>
    </div>
    <?php endif; ?>
				<h2>Редактирование</h2>
				<form class="form-horizontal" action="#" id="editForm" method="POST">
					<div class="form-group">
						<label for="slots" class="col-sm-3 control-label">Количество слотов:</label>
						<div class="col-sm-2">
							<div class="input-group">
								<span class="input-group-btn"><button class="btn btn-default" type="button" onClick="minusSlots()">-</button></span>
								<input type="text" class="form-control" id="slots" name="slots" value="<?php echo $server['server_slots'] ?>">
								<span class="input-group-btn"><button class="btn btn-default" type="button" onClick="plusSlots()">+</button></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="port" class="col-sm-3 control-label">Порт:</label>
						<div class="col-sm-2">
								<input type="number" required min="1111" max="60000" class="form-control" id="port" name="port" value="<?php echo $server['server_port'] ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-9">
							<div class="checkbox">
								<label><input type="checkbox" id="editpassword" name="editpassword" onChange="togglePassword()"> Изменить пароль</label>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="password" class="col-sm-3 control-label">Пароль:</label>
						<div class="col-sm-4">
							<input type="password" class="form-control" id="password" name="password" placeholder="Пароль" disabled>
						</div>
					</div>
					<div class="form-group">
						<label for="password2" class="col-sm-3 control-label">Повторите пароль:</label>
						<div class="col-sm-4">
							<input type="password" class="form-control" id="password2" name="password2" placeholder="Повторите пароль" disabled>
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-9">
							<button type="submit" class="btn btn-primary">Изменить</button>
						</div>
					</div>
				</form>
				</div>
				
				<div id="ver" class="tab-pane fade">
	<div class="panel panel-default">
					<div class="panel-heading">Сменить версию сервера</div>
 <div class="panel-body">
 <?php if($server['game_query'] == 'samp'): ?>
				<button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-warning btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'svz')"><span class="glyphicon glyphicon-refresh"></span> SA:MP 0.3z</button>
                <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-info btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'svx')"><span class="glyphicon glyphicon-refresh"></span> SA:MP 0.3x</button>	
                <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-success btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'sve')"><span class="glyphicon glyphicon-refresh"></span> SA:MP 0.3e</button>
                <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-primary btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'sv037')"><span class="glyphicon glyphicon-refresh"></span> SA:MP 0.3.7</button>
                <button style="width: 105px;margin-bottom: 5px;" type="button" class="btn btn-danger btn-xs" onClick="sendAction(<?php echo $server['server_id'] ?>,'cve')"><span class="glyphicon glyphicon-refresh"></span> CR:MP 0.3e</button>
				<?php endif; ?>
				</div>
				</div>
				</div>
				<div id="stat" class="tab-pane fade">
				<?php if($server['server_status'] == 2){ ?>
				<div class="panel panel-default">
					<div class="panel-heading">Статистика сервера</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-5">
								<table class="table">
									<?php if($query): ?> 
									<tr>
										<th>Название:</th>
										<td><?php echo $query['hostname'] ?></td>
									</tr>
									<tr>
										<th>Игроки:</th>
										<td><?php echo $query['players'] ?> из <?php echo $query['maxplayers'] ?></td>
									</tr>
									<tr>
										<th>Игровой режим:</th>
										<td><?php echo $query['gamemode'] ?></td>
									</tr>
									<tr>
										<th>Карта:</th>
										<td><?php echo $query['mapname'] ?></td>
									</tr>
									<?php endif; ?>
									<tr>
										<th>Нагрузка CPU</th>
										<td>~ <?php echo $server['server_cpu_load'] ?>%</td>
									</tr>
									<tr>
										<th>Нагрузка RAM</th>
										<td>~ <?php echo $server['server_ram_load'] ?>%</td>
									</tr>
								</table>
							</div>
							<div class="col-md-7">
								<div id="statsGraph" style="height: 220px;"></div>
							</div>
						</div>
					</div>
				</div>
				<?php }else{ echo "<div class='alert alert-danger'><b>Ошибка!</b> Для просмотра статистики сервер должен быть включен.</div>"; } ?>
				</div>
				<div id="config" class="tab-pane fade">
<?php
if($server['game_query'] == 'samp'):
$config = "server.cfg";
endif;
$cfg = file_get_contents('ftp://gs'.$server['server_id'].':'.$server['server_password'].'@'.$server['location_ip'].':21/'.$config.'');
if(isset($_REQUEST['otp'])){
$context = stream_context_create(array('ftp'=>array('overwrite' => true)));
$fopen=fopen('ftp://gs'.$server['server_id'].':'.$server['server_password'].'@'.$server['location_ip'].'/'.$config.'',"w",false,$context);
$fputs=fputs($fopen,$_REQUEST['txt']);
fclose($fopen);
if($fputs):
  echo '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">×</a><b>Выполнено!</b> Вы успешно отредактировали конфигурацию сервера.</div>';
else:
  echo '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">×</a><b>Ошибка!</b> При редактировании конфигурации произошла ошибка.</div>';
endif;
}
?>
				<form name=forma method='POST'>
<div class="form-group">
<div class="panel panel-default">
<div class="panel-heading">Редактор конфигурации</div>
<textarea name=txt class="form-control" rows="20"><?php echo $cfg ?></textarea>
</div>
<button type="submit" name=otp class="btn btn-default">Сохранить</button>
</div>
</form>
				</div>
				
				<div id="cmd" class="tab-pane fade">
				<?php if($server['server_status'] == 2){ ?>
							<?php
							$output = $ssh2Lib->execute($link, "sudo tail -n 10 /home/gs".$server['server_id']."/server_log.txt");
								if($_POST['cmd_console']):
									require_once('./engine/libs/SampRconAPI.php');
									$cfg = file_get_contents('ftp://gs'.$server['server_id'].':'.$server['server_password'].'@'.$server['location_ip'].':21/server.cfg');
									$pass = explode("\n",$cfg);
									$pass = substr($pass[2], 14);
									$cmd = $_POST['cmd'];
									$server_cmd = new SampRconAPI($server['location_ip'],$server['server_port'], $pass);
									if($server_cmd->isOnline()) $result = $server_cmd->call($cmd);
									
									if(empty($result[0])):
										echo '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">×</a><b>Выполнено!</b> Команда <code>'.$cmd.'</code> успешно отправлена!</div>';
									else:
									  echo '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">×</a><b>Ошибка!</b> При отправке команды <code>'.$cmd.'</code> произошла ошибка!</div>';
									endif;
								endif;
							?>
							<textarea disabled class="form-control" rows="15" style="color: #fff; background: #000; border: #000;"><?php echo $output; ?></textarea><br/>
							<form role="form" method='POST'>
							  <div class="form-group">
							  <div class="row">
			<div class="col-xs-12 col-md-12 col-lg-12">
				<div class="input-group">
					<span class="input-group-addon">Команда</span>
					<input required type="text" name="cmd" class="form-control" placeholder="Введите команду">
					<span class="input-group-btn">
					  <input type="hidden" name="cmd_console" value="true">
						<button class="btn btn-danger" type="sumbit">Отправить</button>
					</span>
				</div>
		</div>
</form>
</div>
</div>
<?php }else{ echo "<div class='alert alert-danger'><b>Ошибка!</b> Сервер выключен, консоль недоступна.</div>"; } ?>
</div>
<?php } ?>
				     
				<script>
					$('#editForm').ajaxForm({ 
						url: '/admin/servers/control/ajax/<?php echo $server["server_id"] ?>',
						dataType: 'text',
						success: function(data) {
							console.log(data);
							data = $.parseJSON(data);
							switch(data.status) {
								case 'error':
									showError(data.error);
									break;
								case 'success':
									showSuccess(data.success);
									setTimeout("reload()", 1500);
									break;
							}
							$('button[type=submit]').prop('disabled', false);
						},
						beforeSubmit: function(arr, $form, options) {
							$('button[type=submit]').prop('disabled', true);
						}
					});
					function togglePassword() {
						var status = $('#editpassword').is(':checked');
						if(status) {
							$('#password').prop('disabled', false);
							$('#password2').prop('disabled', false);
						} else {
							$('#password').prop('disabled', true);
							$('#password2').prop('disabled', true);
						}
					}

					var serverStats = [
						<?php foreach($stats as $item): ?> 
						[<?php echo strtotime($item['server_stats_date']) * 1000 ?>, <?php echo $item['server_stats_players'] ?>],
						<?php endforeach; ?> 
					];
					$.plot($("#statsGraph"), [serverStats], {
						xaxis: {
							mode: "time",
							timeformat: "%H:%M"
						},
						series: {
							lines: {
								show: true,
								fill: true
							},
							points: {
								show: true
							}
						},
						grid: {
							borderWidth: 0
						},
						colors: [ "#49AFCD" ]
					});
					function sendAction(serverid, action) {
						switch(action) {
							case "delete":
							{
								if(!confirm("Вы уверенны в том, что хотите удалить сервер? Все данные будут удалены.")) return;
								break;
							}
							case "reinstall":
							{
								if(!confirm("Вы уверенны в том, что хотите переустановить сервер? Все данные будут удалены.")) return;
								break;
							}
							case "svz":
							{
								if(!confirm("Вы уверенны в том, что хотите изменить версию сервера на SA:MP 0.3z? Сервер будет переустановлен.")) return;
								break;
							}
							case "svx":
							{
								if(!confirm("Вы уверенны в том, что хотите изменить версию сервера на SA:MP 0.3x? Сервер будет переустановлен.")) return;
								break;
							}
							case "sve":
							{
								if(!confirm("Вы уверенны в том, что хотите изменить версию сервера на SA:MP 0.3e? Сервер будет переустановлен.")) return;
								break;
							}
							case "sv037":
							{
								if(!confirm("Вы уверенны в том, что хотите изменить версию сервера на SA:MP 0.3.7? Сервер будет переустановлен.")) return;
								break;
							}
							case "cve":
							{
								if(!confirm("Вы уверенны в том, что хотите изменить версию сервера на CR:MP 0.3e? Сервер будет переустановлен.")) return;
								break;
							}
							case "delldb":
							{
								if(!confirm("Вы уверенны в том, что хотите отключить базу данных? Все записи и таблицы будут удалены.")) return;
								break;
							}
							case "quota50":
							{
								if(!confirm("Вы уверенны в том, что хотите изменить дисковую квоту пользователю до 50 МБ?")) return;
								break;
							}
							case "quota150":
							{
								if(!confirm("Вы уверенны в том, что хотите изменить дисковую квоту пользователю до 150 МБ?")) return;
								break;
							}
							case "quota300":
							{
								if(!confirm("Вы уверенны в том, что хотите изменить дисковую квоту пользователю до 300 МБ?")) return;
								break;
							}
						}
						$.ajax({ 
							url: '/admin/servers/control/action/'+serverid+'/'+action,
							dataType: 'text',
							success: function(data) {
								console.log(data);
								data = $.parseJSON(data);
								switch(data.status) {
									case 'error':
										showError(data.error);
										$('#controlBtns button').prop('disabled', false);
										break;
									case 'success':
										showSuccess(data.success);
										setTimeout("reload()", 1500);
										break;
								}
							},
							beforeSend: function(arr, options) {
								if(action == "reinstall") showWarning("Сервер будет переустановлен в течении 10 секунд!");
								if(action == "start") showWarning("Сервер запускается! Пожалуйста, подождите некоторое время.");
								if(action == "stop") showWarning("Сервер выключится через 10 секунд! Пожалуйста, подождите.");
								if(action == "restart") showWarning("Сервер перезапускается! Пожалуйста, подождите некоторое время.");
								if(action == "delete") showWarning("Сервер удаляется! Пожалуйста, подождите некоторое время.");
								$('#controlBtns button').prop('disabled', true);
							}
						});
					}

					function plusSlots() {
						value = parseInt($('#slots').val());
						$('#slots').val(value+1);
						updateForm();
					}
					function minusSlots() {
						value = parseInt($('#slots').val());
						$('#slots').val(value-1);
						updateForm();
					}
				</script>
<?php $ssh2Lib->disconnect($link); ?>
<?php echo $footer ?>
