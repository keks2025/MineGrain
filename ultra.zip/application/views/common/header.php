<?php
/*
* @Слито RAG20
*/
$userservers = mysql_query("SELECT * FROM servers WHERE `user_id` = ".$_SESSION['user_id']."");
$userserverscount = mysql_num_rows( $userservers);
$usertickets = mysql_query("SELECT * FROM tickets WHERE `user_id` = ".$_SESSION['user_id']."");
$userticketscount = mysql_num_rows( $usertickets);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="<?php echo $description ?>">
	<meta name="keywords" content="<?php echo $keywords ?>">
	<meta name="generator" content="LitePanel">
	
	<title><?php echo $title ?></title>
    
    <link href="/application/public/css/main.css" rel="stylesheet">
    <link href="/application/public/css/bootstrap.min.css" rel="stylesheet">
	<!--link href="/application/public/css/bootstrap-theme.min.css" rel="stylesheet"-->
	
	<script src="/application/public/js/jquery.min.js"></script>
	<script src="/application/public/js/jquery.nicescroll.js"></script>
	<script src="/application/public/js/jquery.form.min.js"></script>
	<script src="/application/public/js/jquery.flot.min.js"></script>
	<script src="/application/public/js/jquery.flot.time.min.js"></script>
	<script src="/application/public/js/bootstrap.min.js"></script>
	<script src="/application/public/js/main.js"></script>
	<script>
	$(document).ready(
    function() {
        $("html").niceScroll();
    }
);
	</script>
	<script type="text/javascript">
  function hideLoading() {
	document.getElementById('pageIsLoading').style.display = 'none';
  }
  </script>

</head>
<body>
<script type="text/javascript">
    var reformalOptions = {
        project_id: 970396,
        project_host: "ultra-host.reformal.ru",
        tab_orientation: "left",
        tab_indent: "50%",
        tab_bg_color: "#736e6b",
        tab_border_color: "#FFFFFF",
        tab_image_url: "http://tab.reformal.ru/T9GC0LfRi9Cy0Ysg0Lgg0L%252FRgNC10LTQu9C%252B0LbQtdC90LjRjw==/FFFFFF/2a94cfe6511106e7a48d0af3904e3090/left/1/tab.png",
        tab_border_width: 2
    };
    
    (function() {
        var script = document.createElement('script');
        script.type = 'text/javascript'; script.async = true;
        script.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'media.reformal.ru/widgets/v3/reformal.js';
        document.getElementsByTagName('head')[0].appendChild(script);
    })();
</script><noscript><a href="http://reformal.ru"><img src="http://media.reformal.ru/reformal.png" /></a><a href="http://ultra-host.reformal.ru">Oтзывы и предложения для Ultra Host</a></noscript>
<div id="pageIsLoading"
	style="
		position:          absolute;
		display:            block;
		padding-left:    44px;
		padding-right:  12px;
		width:             auto;
		height:            46px;
		line-height:      46px;
		border:            1px solid #890000;
		color:              #000000;
		font-weight:    bold;
		background-color: #e5e5e5;
		background-image: url(/application/public/img/ajax-loader.gif);
		background-position: 6px center;
		background-repeat: no-repeat;">

		<script type="text/javascript">
			if (typeof window_width == 'undefined' || typeof window_height == 'undefined') {
				var window_width;
				var window_height;
				if( typeof( window.innerWidth ) == 'number' ) {
				  window_width = window.innerWidth;
				  window_height = window.innerHeight;
				} else if( document.documentElement &&
				    ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
				  window_width = document.documentElement.clientWidth;
				  window_height = document.documentElement.clientHeight;
				} else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
				  window_width = document.body.clientWidth;
				  window_height = document.body.clientHeight;
				}
			}
			var left = Math.round((window_width - 200) / 2);
			var top = Math.round(((window_height - 46) / 3) + 46);
			document.getElementById('pageIsLoading').style.left = left+'px';
			document.getElementById('pageIsLoading').style.top = top+'px';
		</script>
	Пожалуйста, подождите...
</div>
<style>
.vk {
	margin-top: 35px;
	float: right;
	padding: 0 35px;
}
</style>
	<!-- Powered by LitePanel -->
	<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#">Ultra Host</a>
			</div>
			<div class="collapse navbar-collapse">
				<ul class="nav navbar-nav">
					<li<?php if($activesection == "main"): ?> class="active"<?php endif; ?>><a href="/main/index"><span class="glyphicon glyphicon-home"></span> Главная</a></li>
					<li<?php if($activesection == "rules"): ?> class="active"<?php endif; ?>><a href="/rules"><span class="glyphicon glyphicon-list-alt"></span> Оферта</a></li>
					<li<?php if($activesection == "faq"): ?> class="active"<?php endif; ?>><a href="/faq"><span class="glyphicon glyphicon-book"></span> FAQ</a></li>
					<li<?php if($activesection == "monitor"): ?> class="active"<?php endif; ?>><a href="/main/monitor"><span class="glyphicon glyphicon-stats"></span> Мониторинг</a></li>
					<li<?php if($activesection == "promo"): ?> class="active"<?php endif; ?>><a href="/promo"><span class="glyphicon glyphicon-tag"></span> Купон</a></li>
					<li><a href="http://forum.ultra-host.ru"><span class="glyphicon glyphicon-comment"></span> Форум</a></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown"><img src="<?php if($user_avatar != ""): echo $user_avatar; else: echo "/application/public/img/no-ava.png"; endif; ?>" style="width:18px; height:18px;"> <?php echo $user_firstname ?> <?php echo $user_lastname ?><b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="/account/pay"><span class="glyphicon glyphicon-usd"></span> Баланс: <?php echo $user_balance ?> руб.</a></li>
							<li><a href="/account/edit"><span class="glyphicon glyphicon-wrench"></span> Настройки</a></li>
							<li class="divider"></li>
							<li><a href="/account/logout"><span class="glyphicon glyphicon-log-out"></span> Выход</a></li>
						</ul>
			</div>
		</div>
    </div>
    <div class="vk">
		<a href="https://vk.com/uhosting" target="_blank"><img src="/application/public/img/vk1.png" title="Мы вконтакте"> </a>
		</div>
    <div class="container">
    	<div class="row">
    		<div class="col-md-3">
    			<?php if($user_access_level >= 2): ?>
    			<div class="text-center">
					<div class="btn-group btn-group-sm">
						<button type="button" class="btn btn-default<?php if($activesection != "admin"): ?> active<?php endif; ?>" id="userNavModeBtn" onClick="setNavMode('user')">Пользователь</button>
						<button type="button" class="btn btn-default<?php if($activesection == "admin"): ?> active<?php endif; ?>" id="administratorNavModeBtn" onClick="setNavMode('administrator')">Администратор</button>
					</div>
    			</div>
    			<?php endif; ?> 
    			<div id="userNavMode"<?php if($activesection == "admin"): ?> style="display: none;"<?php endif; ?>>
					<h3>Сервера</h3>
					<div class="list-group">
						<a href="/servers/index" class="list-group-item<?php if($activesection == "servers" && $activeitem == "index"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-hdd"></span> Мои сервера <span class="badge badge-danger"><?php echo $userserverscount; ?></span></a>
						<a href="/servers/order" class="list-group-item<?php if($activesection == "servers" && $activeitem == "order"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-plus"></span> Заказать сервер</a>
					</div>
					<h3>Поддержка</h3>
					<div class="list-group">
						<a href="/tickets/index" class="list-group-item<?php if($activesection == "tickets" && $activeitem == "index"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-headphones"></span> Мои запросы <span class="badge badge-danger"><?php echo $userticketscount; ?></span></a>
						<a href="/tickets/create" class="list-group-item<?php if($activesection == "tickets" && $activeitem == "create"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-plus"></span> Создать запрос</a>
					</div>
					<h3>Аккаунт</h3>
					<div class="list-group">
						<a href="/account/pay" class="list-group-item<?php if($activesection == "account" && $activeitem == "pay"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-usd"></span> Пополнение баланса</a>
						<a href="/account/invoices" class="list-group-item<?php if($activesection == "account" && $activeitem == "invoices"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-list"></span> Счета</a>
						<a href="/account/waste" class="list-group-item<?php if($activesection == "account" && $activeitem == "waste"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-list-alt"></span> Расходы</span></a>
						<a href="/account/referals" class="list-group-item<?php if($activesection == "account" && $activeitem == "referals"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-asterisk"></span> Реферальная программа</a>
						<a href="/account/edit" class="list-group-item<?php if($activesection == "account" && $activeitem == "edit"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-wrench"></span> Настройки</a>
						<a href="/account/logout" class="list-group-item"><span class="glyphicon glyphicon-log-out"></span> Выход</a>
					</div>
				</div>
				<?php if($user_access_level >= 2): ?>
    			<div id="administratorNavMode"<?php if($activesection != "admin"): ?> style="display: none;"<?php endif; ?>>
    				<?php if($user_access_level >= 2): ?> 
					<h3>Поддержка</h3>
					<div class="list-group">
						<a href="/admin/servers/index" class="list-group-item<?php if($activesection == "admin" && $activeitem == "servers"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-hdd"></span> Все сервера</a>
						<a href="/admin/tickets/index" class="list-group-item<?php if($activesection == "admin" && $activeitem == "tickets"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-headphones"></span> Все запросы</a>
						<a href="/admin/users/index" class="list-group-item<?php if($activesection == "admin" && $activeitem == "users"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-user"></span> Все пользователи</a>
						<a href="/admin/invoices/index" class="list-group-item<?php if($activesection == "admin" && $activeitem == "invoices"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-list"></span> Все счета</a>
						<a href="/admin/waste/index" class="list-group-item<?php if($activesection == "admin" && $activeitem == "waste"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-list-alt"></span> Все расходы</a>
					</div>
					<?php endif; ?> 
					<?php if($user_access_level >= 3): ?> 
					<h3>Управление</h3>
					<div class="list-group">
						<a href="/admin/games/index" class="list-group-item<?php if($activesection == "admin" && $activeitem == "games"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-tower"></span> Все игры</a>
						<a href="/admin/locations/index" class="list-group-item<?php if($activesection == "admin" && $activeitem == "locations"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-globe"></span> Все локации</a>
						<a href="/admin/promo" class="list-group-item<?php if($activesection == "admin" && $activeitem == "createPromo"): ?> active<?php endif; ?>"><span class="glyphicon glyphicon-gift"></span> Создать купон</a>
					</div>
					<?php endif; ?> 
				</div>
				<?php endif; ?>
    		</div>
    		<div id="content" class="col-md-9">
				<?php if(isset($error)): ?><div class="alert alert-danger"><strong>Ошибка!</strong> <?php echo $error ?></div><?php endif; ?> 
				<?php if(isset($warning)): ?><div class="alert alert-warning"><strong>Внимание!</strong> <?php echo $warning ?></div><?php endif; ?> 
				<?php if(isset($success)): ?><div class="alert alert-success"><strong>Выполнено!</strong> <?php echo $success ?></div><?php endif; ?> 
