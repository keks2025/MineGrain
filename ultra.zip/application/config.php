<?php
/*
* @LitePanel
* @Developed by QuickDevel
*/
$config = array(
	// Название компании.
	// Пример: ExampleHost
	'title'			=>		'Ultra Host | Панель управления',
	
	// Описание компании (meta description).
	// Пример: Game Hosting ExampleHost
	'description'	=>		'Ultra Host - Дешёвый хостинг игровых серверов SA:MP.',
	
	// Ключевые слова (meta keywords).
	// Пример: game hosting, game servers
	'keywords'		=>		'game hosting, game servers,free game hosting,free samp hosting,бесплатный игровой хостинг,бесплатный хостинг серверов самп,получить игровой сервер бесплатно',
	
	// URL панели управления.
	// Обратите внимание на то, что панель управления должна располагаться в корне (под)домена.
	// http://example.com/, http://cp.example.com/, http://panel.example.com/ - правильно.
	// http://example.com/panel/ - неправильно.
	'url'			=>		'http://mydomain/',
	
	// Токен.
	// Используется для запуска скриптов из Cron`а.
	'token'			=>		'ultratoken892',
	
	// Тип СУБД.
	// По умолчанию поддерживается только СУБД MySQL (mysql).
	'db_type'		=>		'mysql',
	
	// Хост БД.
	// Пример: localhost, 127.0.0.1, db.example.com и пр.
	'db_hostname'	=>		'localhost',
	
	// Имя пользователя СУБД.
	'db_username'	=>		'root',
	
	// Пароль пользователя СУБД.
	'db_password'	=>		'dbpass',
	
	// Название БД.
	'db_database'	=>		'game',
	
	// E-Mail отправителя.
	// Пример: support@example.com, noreply@example.com
	'mail_from'		=>		'support@ultra-host.ru',
	
	// Имя отправителя.
	// Пример: ExampleHost Support
	'mail_sender'	=>		'Ultra Host Support',
	
	// URL мерчанта.
	// Для активированных аккаунтов - https://merchant.roboxchange.com
	// Для неактивированных аккаунтов - http://test.robokassa.ru/Index.aspx
	'rk_server'		=>		'http://www.free-kassa.ru/merchant/cash.php',
	
	// Логин в системе ROBOKASSA.
	'rk_login'		=>		'10238',
	
	// Пароль №1 в системе ROBOKASSA.
	'rk_password1'	=>		'3mc84cxr',
	
	// Пароль №2 в системе ROBOKASSA.
	'rk_password2'	=>		'dsqkhuxr'
);
?>
